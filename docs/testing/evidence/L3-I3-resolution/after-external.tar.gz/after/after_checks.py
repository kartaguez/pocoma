from pathlib import Path
import subprocess,json
P=Path(__file__).parent
ROOT=Path('/private/tmp/pocoma-v3-postaud')
C='pocoma-l3-i3-remediation-after'
def sql(text,role='postgres',expect=0):
    result=subprocess.run(['docker','exec','-i',C,'psql','-X','-q','-A','-t','-v','ON_ERROR_STOP=1','-U',role,'-d','audit_write'],input='\\set VERBOSITY sqlstate\nset search_path=audit;\n'+text,text=True,capture_output=True)
    assert (result.returncode==0)==(expect==0), 'unexpected psql outcome'
    return result
params=dict(expected_database='audit_write',expected_schema='audit',expected_admin='postgres',authority='WRITE',runtime_role='audit_w',reactivation_role='audit_a',injector_role='audit_i',environment='DEV',fixture_identity='false',identity_authority='real',identity_read_role='audit_r',technical_probes='false')
def grant(name,expect=0):
    return sql(''.join('\\set '+k+' '+v+'\n' for k,v in params.items())+(ROOT/'scripts/v3'/name).read_text(),expect=expect)
results=[]
for role,table,stage in [('audit_a','v3_identity_event','grant-l2-discovery.sql'),('audit_i','v3_identity_completion_event','grant-l2-worker-dev.sql')]:
    before=int(sql('select count(*) from '+table).stdout.strip())
    sql('grant truncate on '+table+' to '+role)
    try:
        refused=grant(stage,expect=1)
        assert '42501' in refused.stderr or 'P0001' in refused.stderr
        results.append({'role':role,'table':table,'excess_stage':stage,'excess_rejected':True})
    finally: sql('revoke truncate on '+table+' from '+role)
    grant(stage)
    # The fixture test additionally sends COMMIT after the permission error via JDBC.
    denied=sql('begin;truncate '+table+';commit;',role=role,expect=1)
    assert '42501' in denied.stderr
    assert int(sql('select count(*) from '+table).stdout.strip())==before>0
    results[-1].update({'legitimate_profile_reapplied':True,'postgres_refusal':'42501','rows_before_and_after':before})
# CHECK contains both a token and admission marker in its rejected row, never export stderr/details.
marker='AUDIT_SYNTHETIC_TOKEN_ONLY';context='SYNTHETIC_PRIVATE_ADMISSION_CHECK'
r=sql("insert into v3_identity_request(request_id,requester_issuer,requester_subject,operation,binding_token,target_issuer,target_subject,admission_context,created_at) select gen_random_uuid(),requester_issuer,requester_subject,'INVALID','"+marker+"',target_issuer,target_subject,admission_context||jsonb_build_object('privateMarker','"+context+"'),created_at from v3_identity_request limit 1",role='audit_i',expect=1)
assert '23514' in r.stderr
raw=subprocess.run(['docker','logs',C],capture_output=True,text=True,check=True)
logs=raw.stdout+raw.stderr
receipt={'token_in_server_collector':marker in logs,'admission_marker_in_server_collector':context in logs,'unique_sqlstate_retained':'state=23505' in logs,'check_sqlstate_retained':'state=23514' in logs,'pid_xid_prefix_retained':'xid=' in logs,'raw_logs_exported':False}
assert not receipt['token_in_server_collector'] and not receipt['admission_marker_in_server_collector']
assert receipt['unique_sqlstate_retained'] and receipt['check_sqlstate_retained']
(P/'server-log-observation.json').write_text(json.dumps(receipt,indent=2))
(P/'auxiliary-after.json').write_text(json.dumps(results,indent=2))
# Export only ACL metadata/cardinalities; no token value.
metadata=sql("select row_to_json(x) from (select r.rolname,c.relname,pg_get_userbyid(c.relowner) as owner,has_table_privilege(r.oid,c.oid,'DELETE') as del,has_table_privilege(r.oid,c.oid,'TRUNCATE') as trunc,has_table_privilege(r.oid,c.oid,'TRIGGER') as trig,has_any_column_privilege(r.oid,c.oid,'SELECT') as any_select from pg_roles r cross join pg_class c join pg_namespace n on n.oid=c.relnamespace where r.rolname in ('audit_a','audit_i','audit_w','audit_r') and n.nspname='audit' and c.relname in ('v3_identity_request','v3_eui_authority','v3_pocoma_user','v3_eui_version','v3_identity_request_result','v3_identity_event','v3_identity_completion_event') order by r.rolname,c.relname) x").stdout
(P/'effective-rights.json').write_text(json.dumps([json.loads(x) for x in metadata.splitlines() if x.strip()],indent=2))
(P/'sequences.txt').write_text(sql("select c.relname,r.rolname,has_sequence_privilege(r.oid,c.oid,'USAGE,SELECT,UPDATE') from pg_class c join pg_namespace n on n.oid=c.relnamespace cross join pg_roles r where c.relkind='S' and n.nspname='audit' and r.rolname in ('audit_w','audit_r','audit_a','audit_i') order by 1,2").stdout)
print(json.dumps({'auxiliary':results,'logging':receipt},indent=2))

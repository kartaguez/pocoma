import subprocess,time,json,pathlib,hashlib,tarfile,datetime,shutil
root=pathlib.Path('/Users/julien.guezennec/Dev/projects/pocoma'); out=root/'docs/testing/evidence/verification-optimization'; raw=pathlib.Path('/private/tmp/pocoma-verification-followup');raw.mkdir(exist_ok=False)
baseline=json.loads((out/'baseline-builds.json').read_text()); start_ns=int(datetime.datetime.fromisoformat(baseline[0]['started']).timestamp()*1e9); physical={}
with tarfile.open(out/'baseline-physical.tar.gz','w:gz') as t:
 for path in (root/'app').glob('*/target/**/*'):
  if path.is_file() and 'evidence' in str(path.relative_to(root)).lower() and path.stat().st_mtime_ns>=start_ns:
   name=str(path.relative_to(root));t.add(path,arcname=name);physical[name]=hashlib.sha256(path.read_bytes()).hexdigest()
(out/'baseline-physical.json').write_text(json.dumps(physical,indent=2)+'\n')
results=[]
def measure(label,args):
 command=['./mvnw','--batch-mode','--no-transfer-progress',*args]; print('START',label,flush=True);start=time.time_ns()
 with (raw/(label+'.log')).open('wb') as log:rc=subprocess.run(command,cwd=root/'app',stdout=log,stderr=subprocess.STDOUT).returncode
 result=dict(label=label,command=command,exit_code=rc,seconds=(time.time_ns()-start)/1e9,started_ns=start)
 results.append(result);(out/'followup-builds.json').write_text(json.dumps(results,indent=2)+'\n');print('END',label,rc,round(result['seconds'],3),flush=True)
 return result
anchor=['-pl','runtime-command-consumption-worker','-am']
measure('full-clean-compile',['clean','compile'])
measure('full-compile-hot',['compile'])
measure('identity-clean-compile',anchor+['clean','compile'])
measure('identity-compile-hot',anchor+['compile'])
source=root/'app/domain-user-identity/src/main/java/com/kartaguez/pocoma/domain/useridentity/v3/IdentityTransitions.java'; original=source.read_bytes()
mutation=dict(path=str(source.relative_to(root)),original_sha256=hashlib.sha256(original).hexdigest(),kind='Nonfunctional temporary Java comment; identical bytes restored in finally')
try:
 source.write_bytes(original+b'\n// Controlled compilation timing probe; removed before verification.\n')
 mutation['modified_sha256']=hashlib.sha256(source.read_bytes()).hexdigest()
 measure('identity-compile-after-change',anchor+['compile'])
finally:
 source.write_bytes(original)
mutation['restored_sha256']=hashlib.sha256(source.read_bytes()).hexdigest();(out/'incremental-mutation.json').write_text(json.dumps(mutation,indent=2)+'\n')
measure('identity-compile-after-restore',anchor+['compile'])
measure('full-package-no-test-compilation',['package','-Dmaven.test.skip=true'])
measure('identity-test-compile',anchor+['test-compile'])
measure('identity-local-clean-compile',['-pl','engine-consume-registration,domain-pot','-am','clean','compile'])
measure('identity-local-compile-hot',['-pl','engine-consume-registration,domain-pot','-am','compile'])
with tarfile.open(out/'followup-builds.tar.gz','w:gz') as t:t.add(raw,arcname='followup')
for level,scope,name in [('FAST','identity','fast'),('CHANGE','identity','change-identity'),('INTEGRATION','identity','integration-identity'),('QUARANTINE','i5_r05','quarantine-i5_r05'),('QUARANTINE','i5_r12','quarantine-i5_r12')]:
 print('START CAMPAIGN',level,scope,flush=True)
 rc=subprocess.run(['python3','-B','scripts/testing/verify.py',level,scope,'--output',str(out/name)],cwd=root).returncode
 print('END CAMPAIGN',level,scope,rc,flush=True)
print('FOLLOWUP COMPLETE',flush=True)

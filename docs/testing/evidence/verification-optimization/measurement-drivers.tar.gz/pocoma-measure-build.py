import subprocess,time,json,pathlib,hashlib,tarfile,datetime
root=pathlib.Path('/Users/julien.guezennec/Dev/projects/pocoma'); out=root/'docs/testing/evidence/verification-optimization'; raw=pathlib.Path('/private/tmp/pocoma-verification-baseline');raw.mkdir(exist_ok=False)
commands=[('full-clean-install',['clean','install']),('full-compile',['compile']),('full-test-compile',['test-compile']),('full-package-skipTests',['package','-DskipTests']),('full-install-skipTests',['install','-DskipTests']),('identity-compile',['-pl','runtime-command-consumption-worker','-am','compile']),('identity-test-compile',['-pl','runtime-command-consumption-worker','-am','test-compile']),('identity-compile-hot',['-pl','runtime-command-consumption-worker','-am','compile']),('identity-compile-parallel',['-T','2','-pl','runtime-command-consumption-worker','-am','compile'])]
results=[]
for label,args in commands:
 command=['./mvnw','--batch-mode','--no-transfer-progress',*args]; print('START',label,flush=True);start=time.time_ns()
 with (raw/(label+'.log')).open('wb') as log: rc=subprocess.run(command,cwd=root/'app',stdout=log,stderr=subprocess.STDOUT).returncode
 elapsed=(time.time_ns()-start)/1e9
 reports={}
 for path in (root/'app').glob('*/target/surefire-reports/TEST-*.xml'):
  if path.stat().st_mtime_ns>=start:
   dest=raw/label/path.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(path.read_bytes());reports[str(path.relative_to(root))]=hashlib.sha256(path.read_bytes()).hexdigest()
 results.append(dict(label=label,command=command,exit_code=rc,seconds=elapsed,started=datetime.datetime.fromtimestamp(start/1e9,datetime.timezone.utc).isoformat(),reports=reports));(out/'baseline-builds.json').write_text(json.dumps(results,indent=2)+'\n');print('END',label,rc,round(elapsed,3),flush=True)
with tarfile.open(out/'baseline-builds.tar.gz','w:gz') as t:t.add(raw,arcname='baseline')

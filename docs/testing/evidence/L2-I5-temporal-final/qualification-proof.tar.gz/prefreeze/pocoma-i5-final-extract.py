from pathlib import Path
import re,json,datetime
base=Path('/private/tmp/pocoma-i5-final-a2133b6b/W2-B32-MW4')
rx=re.compile(r'Attempt\[retryDeadlines=\{([^}]*)\},w=(\d+),(WRITE|READ),due=(\d+),start=(\d+),store=(\d+)\.\.(\d+),end=(\d+),(\w+),candidates=\[(.*?)\],returned=\[(.*?)\]\]')
lr=re.compile(r'PartitionLease\[consumptionId=ConsumptionId\[value=([^]]+)\], partitionId=(\d+), ownerToken=([^,]+), ownedUntil=([^]]+)\]')
def leases(s):return {f'{c}/{p}':{'token':t,'until':u} for c,p,t,u in lr.findall(s)}
def attempts(s):return [dict(retry=d[0],worker=int(d[1]),authority=d[2],due=int(d[3]),start=int(d[4]),storeStart=int(d[5]),storeEnd=int(d[6]),end=int(d[7]),outcome=d[8],candidates=leases(d[9]),returned=leases(d[10]+']')) for d in rx.findall(s)]
vector=re.compile(r'((?:lease|claim)/[a-f0-9/-]+)=CVector\[token=([^,]+), until=([^,]+), now=([^,]+), pid=(\d+), began=(\d+)\]')
def vectors(s):return {k:dict(token=t,until=u,now=n,pid=int(p),began=int(b)) for k,t,u,n,p,b in vector.findall(s)}
def dt(s):return datetime.datetime.fromisoformat(s.replace('Z','+00:00'))
full=base.joinpath('temporal-v3-W2-B32-MW4-final.txt').read_text()
all_a=attempts('\n'.join(l for l in full.splitlines() if l.startswith('ALL_ATTEMPTS')))
result={'allLeaseAttempts':len(all_a),'stages':[]}
for stage in (1,2):
 txt=base.joinpath(f'temporal-v3-W2-B32-MW4-stage{stage}.txt').read_text()
 aa=attempts('\n'.join(l for l in txt.splitlines() if l.startswith('ATTEMPTS')))
 # stage2 file accumulates preceding stages; select the final two per-worker ATTEMPTS lines.
 lines=[l for l in txt.splitlines() if l.startswith('ATTEMPTS')][-2:]
 aa=attempts('\n'.join(lines))
 phase={'stage':stage,'oracles':'PASS before cleanup','authorities':{},'vectors':[]}
 for authority in ('WRITE','READ'):
  selected=[a for a in aa if a['authority']==authority]
  services=[];jitters=[]
  for a in selected:
   for k in a['candidates']:
    previous=[p for p in all_a if p['worker']==a['worker'] and p['start']<a['start'] and k in p['candidates']]
    p=max(previous,key=lambda p:p['start']) if previous else None
    eligible=max(p['start']+10000000,p['end']) if p and k not in p['returned'] else a['due']
    services.append((a['end']-eligible)/1e6)
   overlap=[p for p in all_a if p['worker']==a['worker'] and p['authority']==authority and p['end']>a['due'] and p['start']<a['end']]
   busy=sum(max(0,min(p['end'],a['end'])-max(p['start'],a['due'])) for p in overlap)
   jitters.append(max(0,a['end']-a['due']-busy-1000000000-len(overlap)*10000000)/1e6)
  phase['authorities'][authority]={'attempts':len(selected),'maxOperationMs':max((a['end']-a['start'])/1e6 for a in selected),'maxNextAttemptCompleteMs':max(services),'maxCumulativeJitterMs':max(jitters),'omittedCandidates':sum(len(a['candidates'])-len(a['returned']) for a in selected)}
 for l in txt.splitlines():
  if not l.startswith(f'PG stage={stage} '):continue
  b,c=l.split(' after=',1);before=vectors(b);after=vectors(c)
  for k,v in before.items():
   w=after[k];assert v['token']==w['token'];assert dt(w['until'])>dt(v['until'])
  phase['vectors'].append({'leases':sum(k.startswith('lease/') for k in before),'claims':sum(k.startswith('claim/') for k in before),'minLeaseOldDeadlineMarginSeconds':min((dt(v['until'])-dt(after[k]['now'])).total_seconds() for k,v in before.items() if k.startswith('lease/')),'minClaimOldDeadlineMarginSeconds':min((dt(v['until'])-dt(after[k]['now'])).total_seconds() for k,v in before.items() if k.startswith('claim/')),'minOldDeadlineMarginSeconds':min((dt(v['until'])-dt(after[k]['now'])).total_seconds() for k,v in before.items()),'maxInitialAgeSeconds':max((dt(v['now'])-(dt(v['until'])-datetime.timedelta(seconds=90 if k.startswith('lease/') else 60))).total_seconds() for k,v in before.items())})
 result['stages'].append(phase)
excess=[l for l in full.splitlines() if l.startswith('C-EXCESS')]
result['excessiveWitnesses']=excess
result['claimsAfterRetirement']=[{'claims':len(vectors(l.split(' after=',1)[0])),'sameTokenExtended':all(v['token']==vectors(l.split(' after=',1)[1])[k]['token'] and dt(vectors(l.split(' after=',1)[1])[k]['until'])>dt(v['until']) for k,v in vectors(l.split(' after=',1)[0]).items())} for l in full.splitlines() if l.startswith('CLAIMS AFTER')]
result['sealedBeforeCleanup']='JOURNAL SEALED' in full
Path('/private/tmp/pocoma-i5-final-metrics.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

begin isolation level repeatable read read only;
select 'users' as relation, count(*) as n,
       md5(coalesce(string_agg(row_to_json(t)::text,E'\n' order by user_id),'')) as fingerprint
from v3_pocoma_user t
union all
select 'anchors',count(*),
       md5(coalesce(string_agg(row_to_json(t)::text,E'\n' order by eui_id),''))
from v3_eui_authority t
union all
select 'history',count(*),
       md5(coalesce(string_agg(row_to_json(t)::text,E'\n' order by eui_id,version),''))
from v3_eui_version t
union all
select 'mutations',count(*),
       md5(coalesce(string_agg(row_to_json(t)::text,E'\n' order by event_id),''))
from v3_identity_event t;
select family, position from v3_event_counter order by family;
commit;

begin isolation level repeatable read read only;
select
    count(*) = 1 as exact_rejection_record,
    bool_and(
        q.status = 'TERMINAL'
        and r.outcome = 'REJECTED'
        and r.rejection = :'expected_rejection'
        and r.target_eui_id is null
        and r.target_version is null
        and (select count(*) from v3_identity_event e where e.request_id = q.request_id) = 0
        and (select count(*) from v3_identity_completion_event c where c.subject_id = q.request_id) = 1
        and (select count(*) from consumption_slot s
             where s.consumption_id = '2999e75c-272d-5afe-a966-c9364ef021fe'
               and s.consumable_id = q.request_id) = 0
        and (select count(*) from v3_event_position p
             join v3_identity_completion_event c using(event_id)
             where c.subject_id = q.request_id and p.family = 'IDENTITY_COMPLETION') = 1
    ) as probe_isolation_and_completion_pass
from v3_identity_request q
join v3_identity_request_result r using(request_id)
where q.request_id = :'rid'::uuid;

select
    c.family,
    c.position = count(p.event_id)
      and (c.position = 0 or (min(p.position) = 1 and max(p.position) = c.position)) as is_dense
from v3_event_counter c
left join v3_event_position p on p.family = c.family
where c.family in ('IDENTITY', 'IDENTITY_COMPLETION')
group by c.family, c.position
order by c.family;
commit;

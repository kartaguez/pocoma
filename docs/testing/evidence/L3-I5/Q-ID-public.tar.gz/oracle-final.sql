begin isolation level repeatable read read only;
select
    (select count(*) from v3_pocoma_user) = 2 as users_count_ok,
    (select count(*) from v3_eui_authority) = 3 as anchors_count_ok,
    (select count(*) from v3_eui_version) = 4 as versions_count_ok,
    (select count(*) from v3_identity_request where status = 'TERMINAL') = 7 as terminal_requests_ok,
    (select count(*) from v3_identity_request_result where outcome = 'CHANGED') = 4 as changed_results_ok,
    (select count(*) from v3_identity_request_result where outcome = 'REJECTED') = 3 as rejected_results_ok,
    (select count(*) from v3_identity_event) = 6 as identity_events_ok,
    (select count(*) from v3_identity_completion_event) = 7 as completion_events_ok,
    (select count(*) from consumption_slot where consumption_id = '2999e75c-272d-5afe-a966-c9364ef021fe') = 0 as zero_slots_ok,
    (select position from v3_event_counter where family = 'IDENTITY') = 6 as counter_identity_ok,
    (select position from v3_event_counter where family = 'IDENTITY_COMPLETION') = 7 as counter_completion_ok;
commit;

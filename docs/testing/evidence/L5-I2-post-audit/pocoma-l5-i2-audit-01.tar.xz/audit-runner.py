import importlib.util
import json
import sys
from pathlib import Path
ROOT=Path('/Users/julien.guezennec/Dev/projects/pocoma')
spec=importlib.util.spec_from_file_location('verify',ROOT/'scripts/testing/verify.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
methods=['sensitiveRequestReadsDeniedAndPendingAdmissionsCommit','identityInsertFailureRollsBackAssociation',
 'deferredPendingChecksStillRejectEffects','narrowedFunctionsPreserveInheritedIntegrityPredicates',
 'rollbackAndOwnerBoundaries','associationForeignKeysAndImmutability','admissionRoleAndIndirectPrivileges',
 'admissionNeverReadsBusinessTables','concurrentSameKeySameIntent']
config=json.loads(v.CONFIG.read_text())
config.setdefault('campaigns',{})['l5-i2-audit']={
 'level':'CHANGE','modules':['runtime-web-api'],
 'tests':{'com.kartaguez.pocoma.infra.persistence.primary.jpa.v3.V3AdmissionPostgresTest':methods},
 'expected_invocations':len(methods),
 'forecast':{'seconds':300,'basis':'9 focused PostgreSQL methods, warm compilation','uncertainty':'bootstrap/compile'}}
definition=v.plan('CHANGE','l5-i2-audit',config=config)
# Read-only Maven dependency inventory, before even the effective-pom command.
import xml.etree.ElementTree as ET
ns=v.NS
poms={}
for p in (ROOT/'app').glob('*/pom.xml'):
 e=ET.parse(p).getroot();poms[e.findtext('m:artifactId','',ns)]=(p,e)
selected=set()
def visit(name):
 if name in selected:return
 selected.add(name)
 for d in poms[name][1].findall('m:dependencies/m:dependency',ns):
  dep=d.findtext('m:artifactId','',ns)
  if dep in poms:visit(dep)
visit('pocoma-runtime-web-api')
assert not any('architecture-tests' in n for n in selected)
print('Pre-Maven source closure:',','.join(sorted(selected)),flush=True)
original=v.effective_inventory
def checked(d,output):
 model,issues=original(d,output)
 actual={p['artifact'] for p in model}
 assert not any('architecture-tests' in n for n in actual)
 assert actual==selected,(actual-selected,selected-actual)
 print('Effective Maven selection checked:',','.join(sorted(actual)),flush=True)
 return model,issues
v.effective_inventory=checked
if '--plan' in sys.argv:
 print(json.dumps(definition,indent=2))
else:
 sys.exit(v.run(definition,Path('/private/tmp/pocoma-l5-i2-audit-01')))

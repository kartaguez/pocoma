from pathlib import Path
import json
root=Path('/Users/julien.guezennec/Dev/projects/pocoma/docs/testing/evidence/L5-I1');commands=[]
for folder in sorted(Path('/private/tmp').glob('pocoma-l5-i1-*')):
 campaign=folder/'campaign.json'
 if campaign.exists():
  for phase,data in json.loads(campaign.read_text()).get('phases',{}).items():
   if isinstance(data,dict) and data.get('command'):commands.append(dict(run=folder.name,phase=phase,command=data['command'],exit_code=data.get('exit_code'),seconds=data.get('seconds'),source_receipt=f'archives/{folder.name}.tar.gz::campaign.json'))
 for rel in ['plan.json','T1/plan.json']:
  plan=folder/rel
  if not plan.exists():continue
  d=json.loads(plan.read_text());result=plan.with_name('result.json');actual=json.loads(result.read_text()) if result.exists() else {}
  if d.get('command'):commands.append(dict(run=folder.name,phase='effective_Maven_argv',command=d['command'],execution_state=actual.get('verdict','NONTERMINAL / preparation only'),exit_code=actual.get('exit_code'),seconds=actual.get('seconds'),source_receipt=f'archives/{folder.name}.tar.gz::{rel}'))
(root/'Executed_Command_Inventory.json').write_text(json.dumps(dict(scope='Formal I1 owners and effective Maven plans; historical execution states preserved. Native diagnostics/compile/Python feedback remain separate development evidence.',commands=commands),indent=2)+'\n')
print('COMMAND_RECORDS',len(commands))

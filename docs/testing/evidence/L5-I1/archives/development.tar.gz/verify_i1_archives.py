from pathlib import Path
import json,tarfile,hashlib,re,io,time
root=Path('/Users/julien.guezennec/Dev/projects/pocoma/docs/testing/evidence/L5-I1')
start=time.monotonic();findings=[];members=0;nested=0
secret=re.compile(rb'\beyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b|-----BEGIN (?:RSA |EC |ENCRYPTED )?PRIVATE KEY-----|\bgh[pousr]_[A-Za-z0-9]{30,}|\bAKIA[0-9A-Z]{16}\b')
canaries=[b'[REDACTED_BINDING_CANARY]',b'[REDACTED_BINDING_CANARY]',b'[REDACTED_BINDING_CANARY]',b'[REDACTED_BINDING_CANARY]']
def sha(data):return hashlib.sha256(data).hexdigest()
def inspect(data,path):
 global members,nested
 if secret.search(data):findings.append({'path':path,'reason':'secret-pattern (value intentionally omitted)'})
 if any(x in data for x in canaries):findings.append({'path':path,'reason':'binding canary (value intentionally omitted)'})
 if path.endswith('.tar.gz'):
  nested+=1
  with tarfile.open(fileobj=io.BytesIO(data)) as tar:
   for member in tar.getmembers():
    if member.isfile():members+=1;inspect(tar.extractfile(member).read(),path+'::'+member.name)
index=json.loads((root/'Archive_Index.json').read_text())
for item in index:
 path=root/item['archive'];data=path.read_bytes();assert sha(data)==item['sha256'],path
 meta=json.loads(path.with_suffix('').with_suffix('.json').read_text());assert meta['sha256']==sha(data)
 with tarfile.open(fileobj=io.BytesIO(data)) as archive:
  names=[x.name for x in archive.getmembers() if x.isfile()];assert len(names)==len(set(names));assert set(names)==set(meta['files'])
  for name in names:
   value=archive.extractfile(name).read();assert sha(value)==meta['files'][name]['published_sha256'],(path,name)
   inspect(value,str(path.relative_to(root))+'::'+name)
result={'archives':len(index),'published_compressed_bytes':sum(i['bytes'] for i in index),'nested_archives':nested,'inspected_nested_members':members,'hashes':'PASS','secret_scan':'PASS' if not findings else 'FAIL','findings':findings,'seconds':time.monotonic()-start,'scope':'Published archive member bytes including nested raw.tar.gz; not a claim of universal secret detection'}
(root/'Archive_Integrity_Check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));assert not findings,'inspect reported paths without exposing values'

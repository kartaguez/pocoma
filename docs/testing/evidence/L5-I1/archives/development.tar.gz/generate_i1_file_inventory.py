from pathlib import Path
import subprocess,json,hashlib
root=Path('/Users/julien.guezennec/Dev/projects/pocoma');out=root/'docs/testing/evidence/L5-I1/File_Inventory.json';reference='f46d63a9bc4505c43610376eeba40a5854431230'
changed=subprocess.check_output(['git','diff','--no-renames','--name-status',reference],cwd=root,text=True).splitlines();records={}
for line in changed:
 status,path=line.split('\t',1);records[path]={'status_from_reference':status}
for p in (root/'docs/testing/evidence/L5-I1').rglob('*'):
 if p.is_file() and 'development' not in p.relative_to(root/'docs/testing/evidence/L5-I1').parts:records.setdefault(str(p.relative_to(root)),{'status_from_reference':'A'})
for name in ['docs/v3/L5_I1_Execution_Report.md','docs/v3/L5_I1_Proof_Manifest.json']:
 if (root/name).exists():records.setdefault(name,{'status_from_reference':'A'})
records.setdefault(str(out.relative_to(root)),{'status_from_reference':'A'})
for name,record in records.items():
 p=root/name
 if p==out:record.update(bytes=None,sha256=None,reason='self-reference; integrity from delivery Git blob')
 elif p.exists():record.update(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 else:record.update(bytes=None,sha256=None,reason='removed from delivery')
 record['kind']='application_or_test' if name.startswith('app/') else 'versioned_tool_or_fixture' if name.startswith('scripts/') else 'evidence' if name.startswith('docs/testing/evidence/L5-I1/') else 'documentation'
scopes=['app','scripts/testing','scripts/bruno-v3','scripts/v3'];trees={scope:subprocess.check_output(['git','rev-parse','HEAD:'+scope],cwd=root,text=True).strip() for scope in scopes}
data={'reference':reference,'qualified_source_sha':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'qualified_git_trees':trees,'file_count':len(records),'files':[{'path':name}|records[name] for name in sorted(records)],'scope':'Full final working-tree delivery delta; archives already expurgated; raw auxiliary development directory excluded after sealing'}
out.write_text(json.dumps(data,indent=2)+'\n');print('INVENTORY',len(records),trees)

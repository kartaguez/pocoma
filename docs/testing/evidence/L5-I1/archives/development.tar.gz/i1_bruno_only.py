import importlib.util, hashlib, json, os, subprocess, time
from pathlib import Path
repo=Path('/private/tmp/pocoma-i1-qualified');output=Path('/private/tmp/pocoma-l5-i1-b1-correction-01');output.mkdir(exist_ok=False)
spec=importlib.util.spec_from_file_location('verify',repo/'scripts/testing/verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
prior=Path('/private/tmp/pocoma-l5-i1-completion-07/T1/provenance.json');expected=json.loads(prior.read_text())['app_inputs'];actual=v.app_inputs();assert expected==actual, 'B1-only reuse requires identical compiled application inputs'
classpath=(repo/'app/runtime-web-api/target/i1-classpath.txt').read_text();command=['java','-Xmx512m','-cp',classpath,'com.kartaguez.pocoma.V3ReadHttpFixture',str(repo),str(output/'B1')]
started=time.monotonic();receipt=dict(start_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),test_application_inputs_reused_from=str(prior),application_inputs_identical=True,command=command,forecast_seconds=900)
with (output/'B1.log').open('wb') as log: code=subprocess.call(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
receipt.update(exit_code=code,seconds=time.monotonic()-started,verdict='NON_PASS')
if code==0:
 requests=[json.loads(x) for x in (output/'B1/requests.jsonl').read_text().splitlines()];assert sorted(r['scenario'] for r in requests)==[f'B{n:02d}' for n in range(1,33)];receipt.update(verdict='B1_LOCAL_PASS',scenarios=len(requests),physical_http_requests=sum(r['requests'] for r in requests))
(output/'campaign.json').write_text(json.dumps(receipt,indent=2)+'\n')
raise SystemExit(code)

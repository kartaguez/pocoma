from pathlib import Path
import json
root=Path('/Users/julien.guezennec/Dev/projects/pocoma');dest=root/'docs/testing/evidence/L5-I1/D4_Observed_Measurements.json';run=Path('/private/tmp/pocoma-l5-i1-architecture-08');assert (run/'result.json').exists()
d=json.loads(dest.read_text());newrun='architecture-08 / 46b94ce69a4b0f42474d38ac10b26daa78bb6b23'
if d.get('last_native_run')!=newrun:
 d['prior_native_run']=d.get('last_native_run');d['prior_native_observations']=d.get('last_native_observations')
 d['last_native_run']=newrun;d['last_native_observations']={p.stem:json.loads(p.read_text()) for p in (run/'physical').glob('Q*.json')};d['last_native_terminal_verdict']=json.loads((run/'result.json').read_text())['verdict'];d['historical_field_note']='earlier_native_*, final_native_*, native_gate_child_memory and final_delta_* are immutable observations from earlier runs, despite their original field names; last_native_run/observations identify the actual latest native invocation.'
 dest.write_text(json.dumps(d,indent=2)+'\n')
print('PHYSICAL',d['last_native_run'],d['last_native_observations']['Q08-memory']['sampledPeak'])

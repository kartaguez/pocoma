from pathlib import Path
import importlib.util,json,time,shutil
spec=importlib.util.spec_from_file_location('archive','/tmp/archive_i1_evidence.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
root=m.DEST;index=json.loads((root/'Archive_Index.json').read_text());by_label={item['label']:item for item in index};records=[]
for name in ['pocoma-l5-i1-worker-isolation-01','pocoma-l5-i1-worker-isolation-02','pocoma-l5-i1-architecture-04','pocoma-l5-i1-pool-initialization-01','pocoma-l5-i1-architecture-05','pocoma-l5-i1-composition-split-01','pocoma-l5-i1-architecture-06','pocoma-l5-i1-http-boundary-01','pocoma-l5-i1-architecture-07','pocoma-l5-i1-optional-port-01','pocoma-l5-i1-architecture-08','pocoma-l5-i1-architecture-feedback-01']:
 source=Path('/private/tmp')/name
 if not ((source/'result.json').is_file() or (source/'campaign.json').is_file() or (source/'T1/result.json').is_file()):continue
 if name in by_label:continue
 started=time.monotonic();item=m.archive(source);by_label[name]=item;records.append(dict(label=name,seconds=time.monotonic()-started,archive_bytes=item['bytes']))
for name in ['archive_i1_evidence.py','generate_i1_metadata.py','i1_architecture_owner_04.py','i1_architecture_owner_05.py','i1_architecture_owner_06.py','i1_architecture_owner_07.py','i1_architecture_owner_08.py','i1_architecture_feedback_owner.py','finish_i1_evidence.py','analyze_i1_phase_costs.py','finalize_i1_delivery.py','generate_i1_file_inventory.py','verify_i1_archives.py','update_i1_physical.py','generate_i1_commands.py','review_i1_delivery.py','scan_i1_plain_files.py','i1_git_prepublication.py']:
 source=Path('/tmp')/name
 if source.is_file():shutil.copy2(source,root/'development'/name)
started=time.monotonic();item=m.archive(root/'development','development');by_label['development']=item;records.append(dict(label='development',seconds=time.monotonic()-started,archive_bytes=item['bytes']))
(root/'Archive_Index.json').write_text(json.dumps(sorted(by_label.values(),key=lambda x:x['label']),indent=2)+'\n')
p=root/'Publication_Collection_Timings.json';prior=json.loads(p.read_text()) if p.is_file() else [];p.write_text(json.dumps(prior+records,indent=2)+'\n');print(json.dumps(records,indent=2))

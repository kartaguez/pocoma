from pathlib import Path
import subprocess,json,re,datetime,hashlib
r=Path('/Users/julien.guezennec/Dev/projects/pocoma');e=r/'docs/testing/evidence/L5-I1';gate=Path('/private/tmp/pocoma-l5-i1-architecture-08/result.json');assert gate.exists(),'terminal gate required before delivery review'
def git(*args):return subprocess.check_output(['git',*args],cwd=r,text=True).strip()
reference='f46d63a9bc4505c43610376eeba40a5854431230';head=git('rev-parse','HEAD');paths=git('diff','--no-renames','--name-only',reference,'HEAD').splitlines()
allowed_app={'composition-runtime-spring','engine-read-command-result','engine-read-current-binding','engine-read-pot','engine-read-registration-result','runtime-monolith','runtime-task-consumption-worker','runtime-web-api','supra-http-read'}
assert all(p.split('/')[1] in allowed_app for p in paths if p.startswith('app/'))
assert not any('/migration/' in p for p in paths)
unchanged=['docs/testing/Reactor_Verification_Policy.md','docs/v3/L5_D1_D6_Ratification_and_D4_Calibration_Decision.md','docs/v3/L5_D4_Read_Calibration_Report.md','docs/v3/L5_D4_Read_Limits_Arbitration_Proposal.md','docs/v3/L5_D6_Gates_Mutualization_Report.md','app/architecture-tests','app/domain-pot','app/domain-user-identity','app/engine-consumption','app/engine-consume-projection-task','app/engine-materialize-current-binding','app/engine-materialize-command-result','app/engine-materialize-registration-result']
for p in unchanged:assert git('rev-parse',reference+':'+p)==git('rev-parse','HEAD:'+p),p
assert not git('diff','HEAD','--','app','scripts/testing','scripts/bruno-v3','scripts/v3'),'source changes after qualified SHA'
files=[r/'docs/v3/L5_I1_Execution_Report.md',r/'docs/v3/L5_I1_Proof_Manifest.json',r/'docs/v3/L5_I1_Human_Ratification_and_GO.md',r/'docs/v3/L5_I1_Implementation_and_Qualification_Plan.md']+list(e.glob('*.md'));broken=[];links=0
for p in files:
 if p.suffix!='.md':continue
 for target in re.findall(r'\[[^\]]*\]\(([^\n)]+)\)',p.read_text()):
  if target.startswith(('https:','http:','#')):continue
  target=target.split('#')[0].strip('<>');links+=1
  if not (p.parent/target).exists():broken.append({'file':str(p.relative_to(r)),'target':target})
assert not broken,broken
integrity=json.loads((e/'Archive_Integrity_Check.json').read_text());index=json.loads((e/'Archive_Index.json').read_text());assert integrity['archives']==len(index);assert integrity['secret_scan']=='PASS';assert json.loads((e/'Plain_File_Secret_Check.json').read_text())['verdict']=='PASS'
assert all(i['bytes']<100*1024*1024 for i in index),'Git host blob size requires chunking'
subprocess.run(['git','diff','--check'],cwd=r,check=True)
s=json.loads((e/'Qualification_Summary.json').read_text());g=json.loads(gate.read_text());assert s['junit_unique']['states']==dict(PASS=40,FAIL=0,ERROR=0,SKIP=0);assert s['bruno']['scenarios']==32
result={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualified_source_sha':head,'source_boundaries':'PASS','unchanged_normative_and_domain_owners':unchanged,'source_tree_clean_since_qualification':True,'local_links_checked':links,'broken_links':broken,'archive_hash_and_secret_scan':'PASS','archives':len(index),'global_gate_actual_verdict':g['verdict'],'global_gate_actual_counts':g['counts'],'JUnit_I1':s['junit_unique'],'Bruno_scenarios':32,'diff_check':'PASS','publication_authorized':True,'human_I1_closure':'NOT RECORDED','global_SPEC10_or_production_approval':'NOT CLAIMED','note':'Review PASS does not change a FAIL/INCONCLUSIVE mandatory gate into PASS; manifest/final verdict retain actual terminal state.'}
(e/'Delivery_Review.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n');print(json.dumps({'source':head,'local_links':links,'archives':len(index),'gate':g['verdict'],'review':'PASS'},indent=2))

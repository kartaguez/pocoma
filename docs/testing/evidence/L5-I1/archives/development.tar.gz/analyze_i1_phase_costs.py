from pathlib import Path
import json,re,xml.etree.ElementTree as ET
out=Path('/Users/julien.guezennec/Dev/projects/pocoma/docs/testing/evidence/L5-I1');runs=[]
for folder in sorted(Path('/private/tmp').glob('pocoma-l5-i1-*')):
 result=folder/'T1/result.json' if (folder/'T1/result.json').exists() else folder/'result.json'
 if not result.exists():continue
 d=json.loads(result.read_text());timing=d.get('timing')
 if not timing and result.with_name('timings.json').exists():timing=json.loads(result.with_name('timings.json').read_text())
 classes=[]
 for p in result.parent.joinpath('reports').rglob('TEST-*.xml'):
  try:e=ET.parse(p).getroot()
  except ET.ParseError:continue
  classes.append({'class':e.get('name'),'module':p.parent.parent.name,'reported_seconds':float(e.get('time',0)),'tests':int(e.get('tests',0)),'failure':int(e.get('failures',0)),'error':int(e.get('errors',0)),'skip':int(e.get('skipped',0))})
 classes.sort(key=lambda x:x['reported_seconds'],reverse=True)
 junit_sum=sum(x['reported_seconds'] for x in classes);maven=(timing or {}).get('phases',{}).get('maven',{}).get('seconds')
 runs.append({'run':folder.name,'verdict':d['verdict'],'counts':d['counts'],'measured_phases':timing,'reported_class_seconds_sum':junit_sum,'maven_minus_reported_classes_seconds':maven-junit_sum if maven is not None else None,'residual_is_not_exclusive_compilation_time':True,'largest_reported_classes':classes[:12]})
feedback=[]
for pattern in ['i1*compile*.log']:
 for p in sorted(Path('/tmp').glob(pattern)):
  text=p.read_text(errors='replace');times=re.findall(r'Total time:\s+([^\n]+)',text);status=re.findall(r'BUILD (SUCCESS|FAILURE)',text)
  feedback.append({'log':p.name,'maven_reported_total_time':times[-1] if times else None,'build':status[-1] if status else 'UNKNOWN','qualification_contribution':'development compile/test-compile feedback only; not a new test PASS'})
data={'scope':'Observed collector/Maven/Class timing windows; overlap is explicit, no invented exclusive phase durations','runs':runs,'development_compile_feedback':feedback,'interpretation':{'compilation':'Source input counts and Maven compile announcements retained. Exclusive compilation wall duration is not instrumented in mixed test runs; residual also contains plugin/JVM/report costs.','fixture_postgresql_junit':'Reported class durations include container/schema/context setup and PG operations. They are not additive to Maven wall time. SQL pg_stat_statements times are a different, server-only observation.','bruno':'Bruno_Observed_Counters.json separates fixture-before-CLI, Java CLI/validation window and Bruno-reported duration; windows overlap.','collection':'Per-run collector phase timings and separately timed publication archives retained. Earlier publication collection not retrospectively invented.','useful_simplifications':'C05 now rejects the forbidden runtime test edge during bounded feedback; initialize both pool connections before SQL oracles; child memory oracle preserves native gate JVM configuration. No new campaign or relaxed oracle proposed to save elapsed time.'}}
(out/'Phase_Cost_Analysis.json').write_text(json.dumps(data,indent=2)+'\n');print('ANALYZED_RUNS',len(runs))

import hashlib,importlib.util,json
from pathlib import Path
repo=Path('/private/tmp/pocoma-i1-qualified');spec=importlib.util.spec_from_file_location('verify',repo/'scripts/testing/verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
old=json.loads(Path('/private/tmp/pocoma-l5-i1-architecture-07/plan.json').read_text())
# Previous effective source inventory selects identities; v.plan revalidates against current sources.
tests={cls:methods for cls,methods in old['expected'].items() if old['expected_modules'][cls]=='pocoma-architecture-tests'}
assert sum(map(len,tests.values()))==167
config=json.loads(v.CONFIG.read_text());config['campaigns']['l5-i1-architecture-feedback']={'level':'INTEGRATION','modules':['architecture-tests'],'tests':tests,'expected_invocations':167,'selection':'whole-classes','forecast':{'seconds':900,'basis':'Actual architecture oracles not reached by previous failed native gate; bounded feedback only, canonical gate still due','uncertainty':'UNMEASURED'}}
definition=v.plan('INTEGRATION','l5-i1-architecture-feedback',config);definition['purpose']='FIRST_ACTUAL_ARCHITECTURE_ORACLES_FEEDBACK_NOT_CANONICAL_GATE';definition['configuration_overlay_sha256']=hashlib.sha256(json.dumps(config,sort_keys=True).encode()).hexdigest()
raise SystemExit(v.run(definition,Path('/private/tmp/pocoma-l5-i1-architecture-feedback-01')))

from pathlib import Path
import json,subprocess,re
ROOT=Path('/Users/julien.guezennec/Dev/projects/pocoma');OUT=ROOT/'docs/testing/evidence/L5-I1';OUT.mkdir(parents=True,exist_ok=True)
config=json.loads((ROOT/'scripts/testing/verification-campaigns.json').read_text());expected=config['campaigns']['l5-i1']['tests'];ids={}
for cls,methods in expected.items():
 prefix='H' if 'HttpContract' in cls else 'Q' if 'Quota' in cls else 'C'
 for n,method in enumerate(methods,1):
  identifier={'webRoot':'C01','monolithRoot':'C02','legacyComponentsRejected':'C03','readOnlyAuthorityAndNoWriteFallback':'C04','typedPortsAndDependencies':'C05','brunoFixtureProvenance':'C06'}[method] if prefix=='C' else f'{prefix}{n:02d}'
  ids[cls+'#'+method]=identifier
valid=['isolated-01','completion-01','isolated-02','completion-02','completion-03','completion-04','completion-05','completion-06','completion-07','final-delta','worker-isolation-01','worker-isolation-02','architecture-04','pool-initialization-01','architecture-05','composition-split-01','architecture-06','http-boundary-01','architecture-07','optional-port-01','architecture-08']
selected={};runs=[];campaigns=[];gates=[];architecture_feedback=[]
for folder in sorted(Path('/private/tmp').glob('pocoma-l5-i1-*')):
 result=folder/'T1/result.json' if (folder/'T1/result.json').is_file() else folder/'result.json'
 if result.is_file():
  d=json.loads(result.read_text());p=result.with_name('provenance.json');prov=json.loads(p.read_text()) if p.exists() else {};head=prov.get('head',{}).get('output','').strip()
  timing=d.get('timing') or json.loads(result.with_name('timings.json').read_text()) if result.with_name('timings.json').exists() else d.get('timing')
  record={'name':folder.name,'source_sha':head,'counts':d['counts'],'verdict':d['verdict'],'command':d.get('command'),'maven_seconds':d.get('seconds'),'timing':timing,'proof':f'archives/{folder.name}.tar.gz::{result.relative_to(folder)}'};runs.append(record)
  if 'architecture-feedback-' in folder.name:architecture_feedback.append(record)
  elif 'architecture-' in folder.name:gates.append(record)
 c=folder/'campaign.json'
 if c.exists():
  d=json.loads(c.read_text());campaigns.append(dict(name=folder.name,seconds=d['seconds'],verdict=d['verdict'],phases=d.get('phases',{}),forecast_exceeded=d.get('forecast_exceeded',False),basis='owner wall clock, includes invocation collection'))
 elif any(prefix in folder.name for prefix in ['worker-isolation-','pool-initialization-','composition-split-']) and result.is_file():
  d=json.loads(result.read_text());campaigns.append(dict(name=folder.name,seconds=d['timing']['campaign_seconds'],verdict=d['verdict'],phases=d['timing']['phases'],forecast_exceeded=False,basis='collector campaign wall clock; correction invalidated Q fixtures'))
for name in valid:
 folder=Path('/private/tmp/pocoma-l5-i1-'+name);p=folder/'T1/result.json' if (folder/'T1/result.json').is_file() else folder/'result.json'
 if not p.exists():continue
 d=json.loads(p.read_text());prov=json.loads(p.with_name('provenance.json').read_text());head=prov['head']['output'].strip()
 for case in d['executions']:
  identity=case['classname']+'#'+case['method']
  if identity in ids:selected[identity]=dict(id=ids[identity],identity=identity,source_sha=head,run=name,seconds=case['seconds'],outcome=case['outcome'],proof=f'archives/pocoma-l5-i1-{name}.tar.gz::{p.relative_to(folder)}')
assert set(selected)==set(ids),(set(ids)-set(selected))
counts={p:sum(item['id'].startswith(p) for item in selected.values()) for p in ['H','Q','C']};assert counts==dict(H=24,Q=10,C=6)
states={outcome:sum(item['outcome']==outcome for item in selected.values()) for outcome in ['PASS','FAIL','ERROR','SKIP']};total=sum(item['seconds'] for item in campaigns)
summary=dict(schema=2,initial_sha='f46d63a9bc4505c43610376eeba40a5854431230',current_source_sha=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),junit_unique={'tests':40,'states':states,'groups':counts,'attribution':'latest trusted observed invocation per identity, including non-PASS; separate mandatory gate verdict; no historical result overwritten'},methods=sorted(selected.values(),key=lambda i:('HQC'.index(i['id'][0]),i['id'])),formal_runs=runs,campaigns=campaigns,t1_b1_cumulative_seconds=total,forecast_seconds=900,forecast_exceeded=total>900,global_gates=gates,global_gate_time_is_separate=True,durable_publication_archival_cost='outside invocation wall clocks, not independently timed retrospectively')
latest_owner=Path('/private/tmp/pocoma-l5-i1-optional-port-01/campaign.json')
if latest_owner.exists():
 assert json.loads(latest_owner.read_text()).get('verdict')=='LOCAL_CONTRIBUTION_PASS', 'Latest local campaign is non-PASS; preserve it and report its exact state, never replace by an older PASS'
fresh=Path('/private/tmp/pocoma-l5-i1-optional-port-01') if Path('/private/tmp/pocoma-l5-i1-optional-port-01/campaign.json').exists() else Path('/private/tmp/pocoma-l5-i1-http-boundary-01'); fresh_full=(fresh/'campaign.json').exists() and json.loads((fresh/'campaign.json').read_text()).get('verdict')=='LOCAL_CONTRIBUTION_PASS'
full=fresh/'B1' if fresh_full else Path('/private/tmp/pocoma-l5-i1-b1-correction-01/B1');delta=full if fresh_full else Path('/private/tmp/pocoma-l5-i1-final-delta/B1');bruno=[]
plan=(ROOT/'docs/v3/L5_I1_Implementation_and_Qualification_Plan.md').read_text();boracles={}
for line in plan.splitlines():
 match=re.match(r'\| (B\d\d) (.*?) \| (.*?) \| (.*?) \|',line)
 if match:boracles[match[1]]={'name':match[2],'oracle':match[3],'requirements':match[4]}
assert len(boracles)==32
for n in range(1,33):
 source=delta if 15<=n<=20 else full;rows=[json.loads(line) for line in (source/'requests.jsonl').read_text().splitlines()];matches=[r for r in rows if r['scenario']==f'B{n:02d}'];assert len(matches)==1
 row=matches[0];bruno.append(row|boracles[row['scenario']]|dict(outcome='PASS',run=source.parent.name,proof=f'archives/{source.parent.name}.tar.gz::B1/bruno.json'))
summary['bruno']={'scenarios':32,'failures':0,'full_qualified_run_requests':sum(json.loads(line)['requests'] for line in (full/'requests.jsonl').read_text().splitlines()),'expense_delta_requests':0 if fresh_full else 6,'fresh_full_qualified_run':full.parent.name,'source_sha':json.loads((full.parent/'campaign.json').read_text()).get('start_head'),'selected_scenarios':bruno,'fixture_provenance':'READ_FIXTURE — NO PUBLIC ADMISSION PROOF','authentication_provider':'NOT QUALIFIED — local signed JWT/JWKS fixture only'}
summary['architecture_feedback_runs']=architecture_feedback
summary['all_controlled_verification_seconds'] = total + sum((g.get('timing') or {}).get('campaign_seconds',0) for g in gates+architecture_feedback)
summary['all_controlled_verification_basis'] = 'Sum of recorded owner/collector monotonic windows; not civil wall time when clocks diverge. See Clock_Measurement_Analysis.json.'
summary['development_feedback_wall_clock'] = 'Not comprehensively instrumented; logs retained, no invented total'
(OUT/'Qualification_Summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
oracles={}
for line in plan.splitlines():
 match=re.match(r'\| ([HQC]\d\d) `([^`]+)` \| (.*?) \| (.*?) \|',line)
 if match:oracles[match[1]]={'method':match[2],'oracle':match[3],'requirements':match[4]}
assert len(oracles)==40
matrix=['# L5/I1 — Exigences, tests et preuves','','Les identités retenues conservent leur SHA et leur état exact ; les FAIL et interruptions initiaux restent dans les archives. Aucun total ne vaut certification globale.','','| ID | Méthode | Exigences / référence du plan | Preuve retenue |','|---|---|---|---|']
for case in summary['methods']:
 row=oracles[case['id']];matrix.append(f"| {case['id']} | `{row['method']}` | {row['requirements']} | {case['run']} / `{case['source_sha'][:8]}` / {case['outcome']} |")
matrix+=['','| Scénario | Exigences / contrat | État et origine | Requêtes |','|---|---|---|---|']
for row in bruno:matrix.append(f"| {row['scenario']} {row['name']} | {row['requirements']} | PASS — {row['run']} | {row['requests']} |")
matrix+=['','Chaque identité complète, oracle, commande et chemin interne d’archive est conservé dans [Qualification_Summary.json](Qualification_Summary.json). Les assertions détaillées figurent au plan I1 §7 et dans les sources versionnées. Les mesures mémoire/JDBC et les réserves d’attribution restent distinctes du résultat JUnit.']
(OUT/'Requirements_Test_Evidence_Matrix.md').write_text('\n'.join(matrix)+'\n')
print(json.dumps({'junit':summary['junit_unique'],'bruno':32,'t1_b1_seconds':total,'forecast_exceeded':total>900},indent=2,ensure_ascii=False))

lines=['# L5/I1 — Temps observés','','Durées murales mesurées par les propriétaires de campagne ; les reprises suivent des corrections identifiées et conservent les reçus initiaux.','','| Campagne locale | Secondes | État terminal exact |','|---|---:|---|']
for c in summary['campaigns']:lines.append(f"| {c['name']} | {c['seconds']:.6f} | {c['verdict']} |")
lines += ['',f"**Cumul contrôlé T1+B1 et corrections ciblées : {total:.6f} s**, estimation 900 s non interruptive. Ce cumul ne décrit pas une exécution initiale entièrement PASS. Développement, préparation antérieure et archivage durable de publication restent hors de ces horloges ; leur durée fine non instrumentée n’est pas inventée.",'','| Gate Architecture | Collecteur monotone (s) | État | Tests / failure / error / skip |','|---|---:|---|---|']
for g in summary['global_gates']:
 t=(g.get('timing') or {}).get('campaign_seconds');c=g['counts'];lines.append(f"| {g['name']} | {t if t is not None else 'non mesuré / préflight'} | {g['verdict']} | {c['tests']} / {c['failures']} / {c['errors']} / {c['skipped']} |")
lines += ['','Feedback Architecture filtré, distinct des gates canoniques : '+', '.join(g['name']+' / '+g['verdict']+' / '+str(g['counts']) for g in architecture_feedback)+'.']
lines += ['','Les gates sont séparées de T1+B1. Les horloges monotone et civile de la dernière gate divergent ; voir [analyse des horloges](Clock_Measurement_Analysis.json), sans réécriture des reçus. Aucun dépassement budgétaire ne constitue un échec. Une interruption technique ne vaut jamais PASS. Découverte/Maven/collecte sont détaillés dans les JSON ; les temps JUnit comprennent parfois fixtures/PG et ne forment pas une ventilation exclusive compilation/PG/JUnit. Aucun timing non instrumenté inventé.']
(OUT/'Observed_Timings.md').write_text('\n'.join(lines)+'\n')

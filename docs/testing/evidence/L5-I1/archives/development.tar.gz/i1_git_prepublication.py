from pathlib import Path
import subprocess,json,datetime
r=Path('/Users/julien.guezennec/Dev/projects/pocoma')
def get(*args):return subprocess.check_output(['git',*args],cwd=r,text=True).strip()
data={'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'branch':get('branch','--show-current'),'source_head':get('rev-parse','HEAD'),'remote_head':get('rev-parse','origin/feat/v3-architecture'),'ahead_behind':get('rev-list','--left-right','--count','HEAD...origin/feat/v3-architecture'),'worktrees':get('worktree','list','--porcelain'),'force_push_authorized':False,'push_authorized':True,'publication':'pending terminal gate and final delivery commit'}
assert data['branch']=='feat/v3-architecture';assert data['remote_head']=='f46d63a9bc4505c43610376eeba40a5854431230';(r/'docs/testing/evidence/L5-I1/Git_Prepublication_Check.json').write_text(json.dumps(data,indent=2)+'\n')

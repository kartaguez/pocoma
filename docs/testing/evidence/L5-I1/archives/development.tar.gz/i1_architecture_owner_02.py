import hashlib, importlib.util, json
from pathlib import Path
repo=Path('/private/tmp/pocoma-i1-qualified')
spec=importlib.util.spec_from_file_location('verify',repo/'scripts/testing/verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
config=json.loads(v.CONFIG.read_text());config['anchors']['GLOBAL_ARCHITECTURE']='architecture-tests'
definition=v.plan('INTEGRATION','GLOBAL_ARCHITECTURE',config)
definition['gate_kind']='GLOBAL_ARCHITECTURE_REQUIRED_BY_POLICY_SECTION_17'
definition['trigger']='V3 HTTP runtime isolation and existing module test dependencies; I1 checkpoint, not Q5 or certification'
definition['configuration_overlay']={'anchors':{'GLOBAL_ARCHITECTURE':'architecture-tests'}}
definition['configuration_overlay_sha256']=hashlib.sha256(json.dumps(config,sort_keys=True).encode()).hexdigest()
raise SystemExit(v.run(definition,Path('/private/tmp/pocoma-l5-i1-architecture-02')))

from pathlib import Path
import subprocess,re,json,datetime
r=Path('/Users/julien.guezennec/Dev/projects/pocoma');e=r/'docs/testing/evidence/L5-I1'
tracked=subprocess.check_output(['git','diff','--name-only','f46d63a9','HEAD'],cwd=r,text=True).splitlines();new=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=r,text=True).splitlines()
pattern=re.compile(rb'\beyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b|-----BEGIN (?:RSA |EC |ENCRYPTED )?PRIVATE KEY-----|\bgh[pousr]_[A-Za-z0-9]{30,}|\bAKIA[0-9A-Z]{16}\b');findings=[];count=0
for name in sorted(set(tracked+new)):
 p=r/name
 if not p.is_file() or name.endswith('.tar.gz') or '/development/' in name:continue
 data=p.read_bytes();count+=1
 if pattern.search(data):findings.append(dict(path=name,reason='secret-pattern, value omitted'))
result=dict(observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),files_scanned=count,findings=findings,verdict='PASS' if not findings else 'FAIL',scope='Changed tracked and deliverable untracked plain files; archive member scan separately recorded; pattern scan is not universal secret detection')
(e/'Plain_File_Secret_Check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));assert not findings

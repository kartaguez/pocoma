import gzip, hashlib, io, json, re, tarfile
from pathlib import Path
DEST=Path('/Users/julien.guezennec/Dev/projects/pocoma/docs/testing/evidence/L5-I1')
DEST.mkdir(parents=True,exist_ok=True)
SECRET_KEYS={'bindingtoken','authorization','xpocomabindingtoken','accesstoken','refreshtoken','idtoken','clientsecret','password','bearerowner','bearerother','bearersameuser','bearerinactive','bearerabsent','bearerforged'}
CANARIES=['[REDACTED_BINDING_CANARY]','[REDACTED_BINDING_CANARY]','[REDACTED_BINDING_CANARY]','[REDACTED_BINDING_CANARY]']
JWT=re.compile(r'\beyJ[A-Za-z0-9_-]*\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]*(?=[^A-Za-z0-9_-]|$)')
def digest(data):return hashlib.sha256(data).hexdigest()
def text_redact(text):
 for token in CANARIES:text=text.replace(token,'[REDACTED_BINDING_CANARY]')
 text=JWT.sub('[REDACTED_JWT]',text)
 text=re.sub(r'(?i)(Bearer\s+)[A-Za-z0-9._~+/=-]+',r'\1[REDACTED_BEARER]',text)
 text=re.sub(r'(?i)((?:bindingToken|binding_token)(?:&quot;|"|\\")?\s*[:=]\s*(?:&quot;|"|\\"))[^"<>\s]+?(?=&quot;|"|\\")',r'\1[REDACTED_BINDING]',text)
 return text

def sanitize(data,name,changes):
 original=data
 if name.endswith('.tar.gz'):
  try:
   source=tarfile.open(fileobj=io.BytesIO(data),mode='r:gz');members=[];modified=False
   for member in source.getmembers():
    if member.isfile():
     value=source.extractfile(member).read();new=sanitize(value,name+'::'+member.name,changes);modified|=new!=value;members.append((member,new))
    else:members.append((member,None))
   if modified:
    result=io.BytesIO()
    with gzip.GzipFile(fileobj=result,mode='wb',mtime=0) as zipped:
     with tarfile.open(fileobj=zipped,mode='w') as target:
      for member,value in members:
       if value is not None:member.size=len(value);target.addfile(member,io.BytesIO(value))
       else:target.addfile(member)
    data=result.getvalue()
  except tarfile.ReadError:pass
 else:
  try:
   text=data.decode('utf-8')
   if name.endswith('.json'):
    try:
     obj=json.loads(text);modified=[False]
     def walk(value):
      if isinstance(value,dict):
       out={}
       for key,item in value.items():
        normalized=re.sub(r'[^a-z]','',key.lower())
        if normalized in SECRET_KEYS and isinstance(item,str):out[key]='[REDACTED_SECRET]';modified[0]=True
        else:out[key]=walk(item)
       return out
      if isinstance(value,list):return [walk(item) for item in value]
      if isinstance(value,str):
       result=text_redact(value);modified[0]|=result!=value;return result
      return value
     clean=walk(obj)
     if modified[0]:text=json.dumps(clean,indent=2,ensure_ascii=False)+'\n'
    except json.JSONDecodeError: text=text_redact(text)
   else:text=text_redact(text)
   data=text.encode('utf-8')
  except UnicodeDecodeError:pass
 if data!=original:changes.append(dict(path=name,original_sha256=digest(original),published_sha256=digest(data)))
 return data

def archive(source,label=None):
 label=label or source.name
 target=DEST/'archives'/(label+'.tar.gz');target.parent.mkdir(exist_ok=True)
 changes=[];files={};result=io.BytesIO()
 with gzip.GzipFile(fileobj=result,mode='wb',mtime=0) as zipped:
  with tarfile.open(fileobj=zipped,mode='w') as tar:
   for path in sorted(source.rglob('*')):
    if not path.is_file() or path.is_symlink():continue
    name=str(path.relative_to(source));raw=path.read_bytes();value=sanitize(raw,name,changes)
    member=tarfile.TarInfo(name);member.size=len(value);member.mtime=0;member.mode=0o600;tar.addfile(member,io.BytesIO(value))
    files[name]=dict(original_sha256=digest(raw),published_sha256=digest(value),bytes=len(value))
 target.write_bytes(result.getvalue())
 metadata=dict(source=str(source),archive=str(target.relative_to(DEST)),sha256=digest(target.read_bytes()),bytes=target.stat().st_size,files=files,redactions=changes,policy='Only secret/canary values redacted. Outcomes, identities, counters, timings and original hashes retained. Original process artifacts remain at the private source path.')
 (DEST/'archives'/(label+'.json')).write_text(json.dumps(metadata,indent=2,ensure_ascii=False)+'\n')
 return {key:metadata[key] for key in ['archive','sha256','bytes']}|{'label':label,'redacted_files':len(changes)}

if __name__=='__main__':
 import sys
 existing=[]
 for folder in sorted(Path('/private/tmp').glob('pocoma-l5-i1-*')):
  if not folder.is_dir() or folder.name=='pocoma-l5-i1-architecture-03':continue
  if not ((folder/'campaign.json').is_file() or (folder/'result.json').is_file()):continue
  existing.append(archive(folder))
 for folder,label in [(Path('/private/tmp/pocoma-i1-bytecode-diagnostic'),'bytecode-diagnostic'),(DEST/'development','development')]:
  if folder.is_dir():existing.append(archive(folder,label))
 (DEST/'Archive_Index.json').write_text(json.dumps(existing,indent=2)+'\n')
 print(json.dumps({'archives':len(existing),'compressed_bytes':sum(item['bytes'] for item in existing),'redacted_members':sum(item['redacted_files'] for item in existing)},indent=2))

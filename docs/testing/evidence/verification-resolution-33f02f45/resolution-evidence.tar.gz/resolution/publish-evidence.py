from pathlib import Path
import hashlib,json,tarfile,importlib.util,subprocess,time
root=Path('/Users/julien.guezennec/Dev/projects/pocoma');base=Path('/private/tmp/pocoma-verify-resolution');dest=root/'docs/testing/evidence/verification-resolution-33f02f45';dest.mkdir(exist_ok=True)
s=importlib.util.spec_from_file_location('v',root/'scripts/testing/verify.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
measurements=[]
for folder in ['before-delayed','after-isolated']:
 for row in json.loads((base/folder/'measurements.json').read_text()):
  log=(base/folder/(row['name']+'.log')).read_text();metric=v.compilation_metrics(log)
  import re
  measurements.append(dict(folder=folder,**row,compiler_events=metric['compiler_events'],announced_recompiled_source_inputs=metric['announced_recompiled_source_inputs'],internal_maven_time=re.findall(r'Total time: (.+)',log)[-1]))
summary=json.loads((base/'independent-checks.json').read_text());summary.update(initial_sha='33f02f4512af0dbafb5c482ec84171801815d82c',audited_sha='d0927d9410ebcd65c221e73c5ecd04e5242fe4e9',measurements=measurements,final_campaign_commands=json.loads((base/'final-campaigns.json').read_text()),findings={f'AUD-VERIFY-{n:03}':'FIXED' for n in range(1,6)},global_verdict='CLOSED WITH RESERVATIONS',global_architecture_gate='NOT REQUIRED / NOT RUN: no module/dependency/contract boundary changed',full_reactor='NOT REQUIRED / NOT RUN: bounded verification tooling and byte-exact source relocation',unexpected_slice_crossing='NONE',declared_slices=['COMMAND/Identity local feedback and runtime composition','FOUNDATION','MONOLITH Identity contribution'],i5='UNCHANGED; not executed; human acceptance with availability reserve; i5_r12 historical FAIL remains',spec10='UNCHANGED / CERTIFICATION NOT RUN')
summary['tooling_regression'] = dict(command=['python3','-B','-m','unittest','-v','scripts/testing/test_verification.py'],tests=30,seconds=0.740,result='PASS',evidence='resolution/selector-tests-final.log')
summary['static_delivery_checks'] = dict(result='PASS',seconds=0.035307749996718485,checks=['archive member hashes and exact member set','published summary/archive hashes','relative document links','no POM/SQL/oracle/SPEC-10/audit changes'],command='python3 -B - (inline independent hash/link/boundary validation)')
# Keep full event reconstruction inside the archive, compact historical aggregates here.
history=json.loads((base/'historical-compiler-recount.json').read_text());summary['historical_compiler_recount']=[{k:r[k] for k in ['archive','member','log_sha256','announced_recompiled_source_inputs']}|dict(compiler_events=len(r['compiler_events'])) for r in history]
(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[]
for folder in ['before-counterexample','fast-identity','foundation-canonical','change-identity','foundation-filtered-fast','foundation-canonical-final','foundation-canonical-repeat','foundation-filtered-change','fast-final','change-final','integration-final']:
 for name in ['plan.json','provenance.json','result.json','raw.tar.gz']:
  p=base/folder/name
  if p.is_file():files.append((p,'resolution/'+folder+'/'+name))
for folder in ['before-builds','after-builds','before-delayed','after-delayed','after-isolated','before-bytecode','after-bytecode']:
 for p in sorted((base/folder).glob('*')):
  if p.is_file():files.append((p,'resolution/'+folder+'/'+p.name))
for name in ['measure.py','incremental-proof.py','sql-proof.py','independent-checks.py','final-campaigns.py','publish-evidence.py','selector-tests-final.log','selector-tests.log','counterexample-final.json','after-counterexample.log','class-output-comparison.json','incremental-bytecode.json','sql-input-proof.json','independent-checks.json','final-campaigns.json','historical-compiler-recount.json']:
 p=base/name;files.append((p,'resolution/'+name))
for name in ['scripts/testing/verify.py','scripts/testing/verification-campaigns.json','scripts/testing/test_verification.py','app/engine-consumption/src/main/java/com/kartaguez/pocoma/engine/write/pot/exception/MissingTerminalConsumptionFailureException.java']:
 files.append((root/name,'resolution/implementation/'+name))
manifest={}
with tarfile.open(dest/'resolution-evidence.tar.gz','w:gz') as t:
 for p,name in files:
  assert name not in manifest
  raw=p.read_bytes();manifest[name]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());t.add(p,arcname=name,recursive=False)
for p in [dest/'summary.json',dest/'resolution-evidence.tar.gz']:
 raw=p.read_bytes();manifest[str(p.relative_to(root))]=dict(bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(dest/'manifest.json').write_text(json.dumps(dict(initial_sha=summary['initial_sha'],archive_members={k:val for k,val in manifest.items() if k.startswith('resolution/')},published_files={k:val for k,val in manifest.items() if not k.startswith('resolution/')},self_identity='Containing Git commit; no recursive self hash'),indent=2)+'\n')
print('Evidence published locally:',len(files),'archive files;', (dest/'resolution-evidence.tar.gz').stat().st_size,'compressed bytes')

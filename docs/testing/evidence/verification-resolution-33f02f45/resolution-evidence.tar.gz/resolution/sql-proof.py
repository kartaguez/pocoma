from pathlib import Path
import importlib.util,time,json,shutil
from unittest.mock import patch
root=Path('/Users/julien.guezennec/Dev/projects/pocoma'); base=Path('/private/tmp/pocoma-verify-resolution');target=base/'after-checkout'
s=importlib.util.spec_from_file_location('v',root/'scripts/testing/verify.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v)
shutil.copytree(root/'scripts/v3',target/'scripts/v3',dirs_exist_ok=True)
start=time.monotonic();definition=v.plan('CHANGE','identity',root=target)
with patch.object(v,'ROOT',target):
 def fingerprint():return {n:v.digest(target/n) for n in v.external_sql_inputs(definition['expected'])}
 initial=fingerprint(); relevant=target/'scripts/v3/bootstrap-l2-routing.sql';unrelated=target/'scripts/v3/reactivate-l2-slot.sql'
 raw=relevant.read_bytes();other=unrelated.read_bytes()
 try:
  unrelated.write_bytes(other+b'\n-- unrelated to Identity CHANGE\n');after_unrelated=fingerprint()
  relevant.write_bytes(raw+b'\n-- relevant external input probe\n');after_relevant=fingerprint()
 finally:relevant.write_bytes(raw);unrelated.write_bytes(other)
 restored=fingerprint()
 assert initial==after_unrelated and initial!=after_relevant and initial==restored
 (base/'sql-input-proof.json').write_text(json.dumps(dict(command=['python3','-B','/private/tmp/pocoma-verify-resolution/sql-proof.py'],scope='CHANGE identity',mode='Static fingerprint mutation on isolated copy; no PostgreSQL executed',seconds=time.monotonic()-start,initial=initial,after_unrelated=after_unrelated,after_relevant=after_relevant,restored=restored,relevant_change_detected=initial!=after_relevant,unrelated_change_invalidates=False),indent=2)+'\n')
 print('SQL fingerprint: 6 actual inputs; relevant change detected, unrelated SQL ignored, exact restoration confirmed')

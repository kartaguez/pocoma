from pathlib import Path
import subprocess,time,json,os
root=Path('/Users/julien.guezennec/Dev/projects/pocoma');base=Path('/private/tmp/pocoma-verify-resolution');rows=[]
campaigns=[('FAST','foundation','foundation-filtered-fast'),('CHANGE','FOUNDATION','foundation-canonical-final'),('CHANGE','FOUNDATION','foundation-canonical-repeat'),('CHANGE','foundation','foundation-filtered-change'),('FAST','identity','fast-final'),('CHANGE','identity','change-final'),('INTEGRATION','identity','integration-final')]
for level,scope,name in campaigns:
 command=['python3','-B','scripts/testing/verify.py',level,scope,'--output',str(base/name)]
 start=time.monotonic()
 with (base/(name+'.log')).open('wb') as log:rc=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
 row=dict(name=name,command=command,exit_code=rc,wall_seconds=time.monotonic()-start)
 result=base/name/'result.json'
 if result.is_file():
  data=json.loads(result.read_text());row.update({k:data[k] for k in ['verdict','counts','seconds','discovery_seconds','issues']})
 rows.append(row);(base/'final-campaigns.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if rc:print((base/(name+'.log')).read_text()[-5000:],flush=True)
env=os.environ.copy();env['_JAVA_OPTIONS']='-Dtest=SpringTransactionRunnerTest -Dsurefire.failIfNoSpecifiedTests=false'
command=['python3','-B','scripts/testing/verify.py','CHANGE','FOUNDATION','--output',str(base/'counterexample-final')]
start=time.monotonic();r=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True)
(base/'counterexample-final.json').write_text(json.dumps(dict(command=command,environment_override={'_JAVA_OPTIONS':env['_JAVA_OPTIONS']},exit_code=r.returncode,wall_seconds=time.monotonic()-start,output=r.stdout+r.stderr),indent=2)+'\n')
print('Exact counterexample return code:',r.returncode,flush=True)

from pathlib import Path
import subprocess,time,json,hashlib
base=Path('/private/tmp/pocoma-verify-resolution')
command=['./mvnw','--batch-mode','--no-transfer-progress','-pl','engine-consume-registration,domain-pot','-am','compile']
rows=[]
for period,folder in [('before','before-checkout'),('after','after-checkout')]:
 root=base/folder; out=base/(period+'-bytecode');out.mkdir()
 source=root/'app/domain-user-identity/src/main/java/com/kartaguez/pocoma/domain/useridentity/BindingId.java'
 target=root/'app/domain-user-identity/target/classes/com/kartaguez/pocoma/domain/useridentity/BindingId.class'
 raw=source.read_bytes();initial=target.read_bytes();mutated=raw.rsplit(b'}',1)[0]+b' public static final String VERIFICATION_PROBE = "pocoma-incremental-probe";\n}\n'
 def run(name):
  start=time.monotonic()
  with (out/(name+'.log')).open('wb') as log:rc=subprocess.run(command,cwd=root/'app',stdout=log,stderr=subprocess.STDOUT).returncode
  row=dict(period=period,name=name,command=command,seconds=time.monotonic()-start,exit_code=rc,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),class_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),class_has_probe=b'VERIFICATION_PROBE' in target.read_bytes())
  rows.append(row);(base/'incremental-bytecode.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
  assert rc==0
 try:
  time.sleep(1.2);source.write_bytes(mutated);run('mutated');assert b'VERIFICATION_PROBE' in target.read_bytes()
 finally:
  time.sleep(1.2);source.write_bytes(raw)
 run('restored');assert target.read_bytes()==initial and b'VERIFICATION_PROBE' not in target.read_bytes()
 run('warm')

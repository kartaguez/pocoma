"""Read-only reconstruction; no selector import, Maven, Docker or inferred test PASS."""
from pathlib import Path
import collections,hashlib,json,tarfile,time,xml.etree.ElementTree as E
base=Path('/private/tmp/pocoma-verify-resolution');root=Path('/Users/julien.guezennec/Dev/projects/pocoma');start=time.monotonic()
rows=[];sets={}
for name in ['foundation-filtered-fast','foundation-canonical-final','foundation-canonical-repeat','foundation-filtered-change','fast-final','change-final','integration-final']:
 path=base/name; result=json.loads((path/'result.json').read_text());plan=json.loads((path/'plan.json').read_text());prov=json.loads((path/'provenance.json').read_text())
 assert hashlib.sha256((path/'raw.tar.gz').read_bytes()).hexdigest()==result['raw_sha256']
 actual=collections.Counter();counters=collections.Counter()
 with tarfile.open(path/'raw.tar.gz') as bundle:
  names=[m.name for m in bundle if m.isfile()];assert len(names)==len(set(names))
  for member in bundle:
   if not member.isfile():continue
   raw=bundle.extractfile(member).read();assert hashlib.sha256(raw).hexdigest()==result['artifacts'][member.name]
   if '/surefire-reports/TEST-' not in member.name or not member.name.endswith('.xml'):continue
   suite=E.fromstring(raw)
   assert int(suite.get('tests'))==len(suite.findall('testcase'))
   for case in suite.findall('testcase'):
    assert all(case.find(t) is None for t in ['skipped','failure','error'])
    actual[(case.get('classname'),case.get('name'))]+=1
 expected=collections.Counter((fqcn,method) for fqcn,methods in plan['expected'].items() for method in methods)
 assert actual==expected and actual and all(n==1 for n in actual.values())
 assert result['verdict']=='PASS' and not result['issues'] and sum(actual.values())==result['counts']['tests']
 for name_sql,sha in prov['external_sql_inputs'].items():assert hashlib.sha256((root/name_sql).read_bytes()).hexdigest()==sha
 assert prov['selector_sha256']==hashlib.sha256((root/'scripts/testing/verify.py').read_bytes()).hexdigest()
 sets[name]=set(actual)
 rows.append(dict(name=name,invocations=len(actual),classes=len(plan['expected']),maven_seconds=result['seconds'],discovery_seconds=result['discovery_seconds'],modules=plan['reactor_modules'],external_sql=sorted(prov['external_sql_inputs']),expected=sorted('#'.join(i) for i in expected),executed=sorted('#'.join(i) for i in actual),verdict='PASS'))
assert sets['fast-final']<sets['change-final']<sets['integration-final']
assert sets['foundation-canonical-final']==sets['foundation-canonical-repeat']==sets['foundation-filtered-change']
assert sets['foundation-filtered-fast']<sets['foundation-canonical-final']
historical={}
for new,old in [('fast-final','fast'),('change-final','change-identity'),('integration-final','integration-identity')]:
 data=json.loads((root/'docs/testing/evidence/verification-optimization'/old/'result.json').read_text())
 previous={(r['classname'],r['method']) for r in data['executions']}
 assert previous==sets[new]
 historical[new]=dict(missing=[],added=[],identical=True)
before=json.loads((base/'before-counterexample/result.json').read_text());assert before['verdict']=='PASS' and before['counts']['tests']==4
counter=json.loads((base/'counterexample-final.json').read_text());assert counter['exit_code']==2 and '_JAVA_OPTIONS is set' in counter['output']
sql=json.loads((base/'sql-input-proof.json').read_text());assert sql['relevant_change_detected'] and not sql['unrelated_change_invalidates']
bytecode=json.loads((base/'incremental-bytecode.json').read_text())
for period in ['before','after']:
 b=[r for r in bytecode if r['period']==period]
 assert b[0]['class_has_probe'] and not b[1]['class_has_probe'] and b[1]['class_sha256']==b[2]['class_sha256']
classes=json.loads((base/'class-output-comparison.json').read_text());assert classes['identical'] and classes['before']==classes['after']
summary=dict(command=['python3','-B','/private/tmp/pocoma-verify-resolution/independent-checks.py'],seconds=time.monotonic()-start,campaigns=rows,identity_inclusions=True,historical_identity_sets=historical,foundation_repeat_identical=True,original_false_pass_tests=4,original_required_tests=28,after_counterexample_exit=2,sql=sql,bytecode=bytecode,restored_class_files_identical=len(classes['before']))
(base/'independent-checks.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(dict(campaigns=len(rows),counts=[r['invocations'] for r in rows],identity_inclusions=True,historical_sets_identical=True,foundation_repeat_identical=True,seconds=summary['seconds'])))

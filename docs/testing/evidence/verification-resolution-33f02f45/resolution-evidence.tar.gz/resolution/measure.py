import subprocess,time,json,pathlib,sys,hashlib
root=pathlib.Path(sys.argv[2]) if len(sys.argv)>2 else pathlib.Path('/Users/julien.guezennec/Dev/projects/pocoma')
out=pathlib.Path('/private/tmp/pocoma-verify-resolution')/sys.argv[1];out.mkdir()
base=['./mvnw','--batch-mode','--no-transfer-progress','-pl','engine-consume-registration,domain-pot','-am']
rows=[]
def run(name,goals):
 command=base+goals;start=time.monotonic()
 with (out/(name+'.log')).open('wb') as f: rc=subprocess.run(command,cwd=root/'app',stdout=f,stderr=subprocess.STDOUT).returncode
 row=dict(name=name,command=command,seconds=time.monotonic()-start,exit_code=rc);rows.append(row);print(row,flush=True)
 (out/'measurements.json').write_text(json.dumps(rows,indent=2)+'\n')
 if rc: raise SystemExit(rc)
run('cold-targets',['clean','compile'])
run('warm-1',['compile']);run('warm-2',['compile'])
p=root/'app/domain-user-identity/src/main/java/com/kartaguez/pocoma/domain/useridentity/BindingId.java'
raw=p.read_bytes()
try:
 time.sleep(1.2)
 p.write_bytes(raw+b'\n// Verification compilation measurement only.\n')
 run('incremental',['compile'])
finally:
 time.sleep(1.2)
 p.write_bytes(raw)
run('restored',['compile']);run('final-warm',['compile'])
(out/'mutation.json').write_text(json.dumps(dict(source=str(p.relative_to(root)),original_sha256=hashlib.sha256(raw).hexdigest(),restored_sha256=hashlib.sha256(p.read_bytes()).hexdigest()),indent=2)+'\n')

import java.nio.file.*;
import java.util.*;
import org.apache.maven.surefire.api.testset.TestListResolver;
class CheckI5Exclusions {
 public static void main(String[] args) throws Exception {
  var patterns = Files.readAllLines(Path.of(args[0])).stream().filter(s -> !s.isBlank() && !s.startsWith("#")).toList();
  if(patterns.size()!=2) throw new AssertionError(patterns);
  var r = new TestListResolver(List.of(),patterns);
  var name = TestListResolver.toClassFileName("com.kartaguez.pocoma.runtime.command.v3.V3WorkerResourcesPostgresTest");
  for(int i=1;i<=12;i++) {
   String method = "i5_r%02d".formatted(i);
   if(r.shouldRun(name,method) != (i!=5 && i!=12)) throw new AssertionError(method);
  }
  if(!r.shouldRun(TestListResolver.toClassFileName("com.kartaguez.pocoma.infra.persistence.primary.jpa.v3.PotHistoryCardinalityPostgresTest"),"uuidAndBigintArraysCrossProtocolBoundaryWithFixedArity")) throw new AssertionError("foreign method excluded");
  System.out.println("PASS Surefire 3.5.5: exactly r05/r12 excluded, ten resource methods and foreign method retained");
 }
}

from pathlib import Path
import subprocess,json,time,hashlib,uuid,xml.etree.ElementTree as ET,statistics
b=Path(__file__).parent; root=b/'cli-tests-final/checkout'; records=[]
# Disposable test clone only. The production wrapper and sources are untouched.
import shutil
shutil.copyfile(root/'app/native/mvnw', root/'app/mvnw')
old=subprocess.check_output(['git','show','6d40ed17496709ce75175c4651dbaaaedc78343e:scripts/testing/verify.py'],cwd=root)
(root/'scripts/testing/verify-before.py').write_bytes(old)
(b/'verify-before.py.txt').write_bytes(old)
for label,script in [('warm-before','verify-before.py'),('warm-after','verify.py')]+[(f'{which}-{n}',script) for n in range(1,4) for which,script in [('before','verify-before.py'),('after','verify.py')]]:
 output=b/('perf-'+label); cmd=['python3','-B','scripts/testing/'+script,'FAST','identity','--output',str(output)]
 started=time.monotonic()
 with (b/('perf-'+label+'.console.log')).open('wb') as log: rc=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
 result=json.loads((output/'result.json').read_text()); assert rc==0 and result['counts']['tests']==65,result
 records.append(dict(name=label,command=cmd,wall_seconds=time.monotonic()-started,maven_seconds=result['seconds'],discovery_seconds=result['discovery_seconds'],compiled_sources=result['compilation']['announced_recompiled_source_inputs']))
 (b/'performance.json').write_text(json.dumps(records,indent=2)+'\n')
source=root/'app/domain-user-identity/src/main/java/com/kartaguez/pocoma/domain/useridentity/BindingId.java'
target=root/'app/domain-user-identity/target/classes/com/kartaguez/pocoma/domain/useridentity/BindingId.class'
raw=source.read_bytes(); initial=target.read_bytes(); mutated=raw.rsplit(b'}',1)[0]+b' public static final String VERIFICATION_PROBE = "pocoma-provenance-incremental-probe";\n}\n'; incremental=[]
def check(name):
 cmd=['python3','-B','scripts/testing/verify.py','FAST','identity','--output',str(b/('incremental-'+name))]
 with (b/('incremental-'+name+'.console.log')).open('wb') as log: rc=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
 r=json.loads((b/('incremental-'+name)/'result.json').read_text()); assert rc==0,r
 incremental.append(dict(name=name,command=cmd,source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),class_sha256=hashlib.sha256(target.read_bytes()).hexdigest(),class_has_probe=b'VERIFICATION_PROBE' in target.read_bytes(),compiled_sources=r['compilation']['announced_recompiled_source_inputs'],maven_seconds=r['seconds']))
 (b/'incremental.json').write_text(json.dumps(incremental,indent=2)+'\n')
try:
 time.sleep(1.2); source.write_bytes(mutated); check('mutated'); assert b'VERIFICATION_PROBE' in target.read_bytes()
finally:
 time.sleep(1.2); source.write_bytes(raw)
check('restored'); assert target.read_bytes()==initial
check('warm'); assert incremental[-1]['compiled_sources']==0
# Direct Failsafe experiment: no new binding, no assertion of CLI lifecycle coverage.
output=b/'failsafe-probe'; output.mkdir(); reports=output/'reports'; reports.mkdir(); runid=uuid.uuid4().hex
p=json.loads((b/'fast/plan.json').read_text()); classes=','.join(sorted(p['expected']))
for module in p['reactor_modules']:
 artifact=ET.parse(root/'app'/module/'pom.xml').getroot().findtext('{http://maven.apache.org/POM/4.0.0}artifactId')
 (reports/artifact/'failsafe-reports').mkdir(parents=True)
cmd=['./mvnw','--batch-mode','--no-transfer-progress','-pl','engine-consume-registration,domain-pot','-am','-Dpocoma.verification.id='+runid,'-Dpocoma.verification.reports='+str(reports),'-Dit.test='+classes,'-Dfailsafe.failIfNoSpecifiedTests=false','test-compile','failsafe:integration-test','failsafe:verify']
started=time.monotonic()
with (output/'maven.log').open('wb') as log: rc=subprocess.run(cmd,cwd=root/'app',stdout=log,stderr=subprocess.STDOUT).returncode
seen=set();producers=set();files=list(reports.rglob('TEST-*.xml'))
for f in files:
 s=ET.parse(f).getroot(); props={p.get('name'):p.get('value') for p in s.findall('properties/property')}
 assert props['pocoma.verification.id']==runid
 assert props['pocoma.verification.module']==f.parent.parent.name
 assert props['pocoma.verification.producer']=='failsafe'; producers.add(f.parent.parent.name)
 for c in s.findall('testcase'):
  assert not any(c.find(k) is not None for k in ['failure','error','skipped'])
  seen.add((c.get('classname'),c.get('name')))
expected={(c,m) for c,ms in p['expected'].items() for m in ms}
result=dict(command=cmd,exit_code=rc,seconds=time.monotonic()-started,invocation_id=runid,reports=len(files),tests=len(seen),modules=sorted(producers),identities=sorted(seen),matches_expected=seen==expected)
(output/'result.json').write_text(json.dumps(result,indent=2)+'\n')
assert rc==0 and seen==expected,result
print(json.dumps({'performance':records,'incremental':incremental,'failsafe':result},indent=2))

from pathlib import Path
import json,subprocess,sys,time
root=Path('/Users/julien.guezennec/Dev/projects/pocoma'); base=Path(__file__).parent; records=[]
for name,level,scope in [('foundation','CHANGE','FOUNDATION'),('fast','FAST','identity'),('change','CHANGE','identity'),('integration','INTEGRATION','identity')]:
 command=[sys.executable,'-B','scripts/testing/verify.py',level,scope,'--output',str(base/name)]
 started=time.monotonic()
 with (base/(name+'.console.log')).open('wb') as log:
  rc=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT).returncode
 result=json.loads((base/name/'result.json').read_text())
 records.append(dict(name=name,command=command,exit_code=rc,wall_seconds=time.monotonic()-started,verdict=result['verdict'],counts=result['counts'],seconds=result.get('seconds'),discovery_seconds=result.get('discovery_seconds')))
 (base/'campaigns.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps(records[-1]),flush=True)
 if rc: sys.exit(rc)

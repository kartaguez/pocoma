"""Read receipts without importing the selector or its assessment implementation."""
from pathlib import Path
from collections import Counter
import hashlib,json,tarfile,re,xml.etree.ElementTree as ET
base=Path(__file__).resolve().parent
root=base/'source' if (base/'source/app').is_dir() else Path('/Users/julien.guezennec/Dev/projects/pocoma')
records={}; sets={}
for name,count in [('foundation',28),('fast',65),('change',127),('integration',162)]:
 p=json.loads((base/name/'plan.json').read_text()); r=json.loads((base/name/'result.json').read_text())
 assert r['verdict']=='PASS' and not r['issues'] and r['exit_code']==0,name
 assert hashlib.sha256((base/name/'raw.tar.gz').read_bytes()).hexdigest()==r['raw_sha256']
 expected=Counter((p['expected_modules'][c],c,m) for c,ms in p['expected'].items() for m in ms)
 for classname in p['expected']:
  candidates=[]
  for path in (root/'app').glob('*/src/test/java/**/'+classname.rsplit('.',1)[-1]+'.java'):
   source=path.read_text(); package=re.search(r'^package\s+([\w.]+);',source,re.M)
   if package and package[1]+'.'+path.stem==classname: candidates.append(path)
  assert len(candidates)==1,classname
  module=candidates[0].relative_to(root/'app').parts[0]
  artifact=ET.parse(root/'app'/module/'pom.xml').getroot().findtext('{http://maven.apache.org/POM/4.0.0}artifactId')
  assert artifact==p['expected_modules'][classname],classname
 seen=Counter(); outcomes=Counter(); report_count=0
 with tarfile.open(base/name/'raw.tar.gz') as t:
  entries=[e for e in t if e.isfile()]
  assert len({e.name for e in entries})==len(entries)
  assert set(e.name for e in entries)==set(r['artifacts'])
  for e in entries:
   raw=t.extractfile(e).read(); assert hashlib.sha256(raw).hexdigest()==r['artifacts'][e.name],e.name
   if not (e.name.startswith('reports/') and '/TEST-' in e.name and e.name.endswith('.xml')): continue
   report_count+=1
   parts=Path(e.name).parts; assert len(parts)==4
   s=ET.fromstring(raw); assert s.tag=='testsuite'
   props={x.get('name'):x.get('value') for x in s.findall('properties/property')}
   assert props['pocoma.verification.id']==r['invocation_id']==p['invocation_id']
   assert props['pocoma.verification.module']==parts[1]
   assert props['pocoma.verification.producer']==parts[2].removesuffix('-reports')
   cases=s.findall('testcase'); assert len(cases)==int(s.get('tests'))
   assert all(int(s.get(k))==0 for k in ['failures','errors','skipped'])
   for c in cases:
    assert c.get('classname')==s.get('name')
    assert all(c.find(k) is None for k in ['failure','error','skipped'])
    seen[(parts[1],c.get('classname'),c.get('name'))]+=1
 assert seen==expected and len(seen)==count and all(n==1 for n in seen.values())
 receipt=Counter((p['expected_modules'][e['classname']],e['classname'],e['method']) for e in r['executions'])
 assert receipt==seen
 log=(base/name/'maven.log').read_text()
 log=re.sub(r'\x1b\[[0-9;]*m','',log)
 totals=[int(m[1]) for line in log.splitlines() if ' -- in ' not in line for m in [re.search(r'^\[INFO\] Tests run: (\d+), Failures: 0, Errors: 0, Skipped: 0',line)] if m]
 assert sum(totals)==count,(name,totals)
 assert 'BUILD SUCCESS' in log
 sets[name]=set((c,m) for _,c,m in seen)
 records[name]=dict(tests=len(seen),reports=report_count,hashes_verified=len(entries),maven_log_tests=sum(totals),invocation_id=p['invocation_id'],compiler_source_inputs=r['compilation']['announced_recompiled_source_inputs'])
assert sets['fast']<sets['change']<sets['integration']
assert len({r['invocation_id'] for r in records.values()})==4
# Compare exact current identities to the published audited sets, never reuse them.
root=base/'source' if (base/'source/app').is_dir() else Path('/Users/julien.guezennec/Dev/projects/pocoma')
for name,old in [('fast','fast-final'),('change','change-final'),('integration','integration-final')]:
 archive=root/'docs/testing/evidence/verification-resolution-33f02f45/resolution-evidence.tar.gz'
 with tarfile.open(archive) as t:
  matches=[m for m in t if m.name.endswith('/'+old+'/result.json')]
  assert len(matches)==1
  r=json.load(t.extractfile(matches[0]))
  assert sets[name]=={(e['classname'],e['method']) for e in r['executions']},name
records['coverage']={'fast_subset_change_subset_integration':True,'change_minus_fast':len(sets['change']-sets['fast']),'integration_minus_change':len(sets['integration']-sets['change']),'historical_identity_sets_unchanged':True}
(base/'independent-checks.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))

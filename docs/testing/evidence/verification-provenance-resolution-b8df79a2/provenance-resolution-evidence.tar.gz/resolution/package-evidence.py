from pathlib import Path
import hashlib,json,subprocess,tarfile,statistics
root=Path('/Users/julien.guezennec/Dev/projects/pocoma'); base=Path(__file__).parent
out=root/'docs/testing/evidence/verification-provenance-resolution-b8df79a2'
initial='b8df79a2c5067bffa92b52e3a08a65e929ce716b'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path): return json.loads(path.read_text())
def command(args): return subprocess.check_output(args,cwd=root,text=True)
code=['app/pom.xml','scripts/testing/verify.py','scripts/testing/test_verification.py','scripts/testing/test_verification_cli.py','scripts/testing/verification-campaigns.json']
checks={}
for name in ['foundation','fast','change','integration']:
 r=load(base/name/'result.json'); p=load(base/name/'provenance.json')
 assert r['verdict']=='PASS' and p['selector_sha256']==sha(root/'scripts/testing/verify.py')
 assert p['app_inputs']['app/pom.xml']==sha(root/'app/pom.xml')
 assert not r['issues']
 checks[name]=dict(selector_matches_final=True,pom_matches_final=True)
for n in ['docs/v3/SPEC-10_Test_Certification.md','scripts/testing/verification-campaigns.json','docs/v3/Verification_AUD_VERIFY_001_Independent_Counter_Audit.md']:
 original=subprocess.check_output(['git','show',initial+':'+n],cwd=root)
 assert original==(root/n).read_bytes();checks[n]='UNCHANGED'
assert not (root/'app/.verification.lock').exists()
assert 'Ran 10 tests in 83.819s\n\nOK' in (base/'cli-tests-publication.log').read_text()
assert 'Ran 30 tests in 0.726s\n\nOK' in (base/'unit-final.log').read_text()
checks.update(initial_sha=initial,current_head=command(['git','rev-parse','HEAD']).strip(),branch=command(['git','branch','--show-current']).strip(),remote_before=(base/'remote-before-publication.txt').read_text().strip(),unexpected_slice_crossings='NONE',global_architecture_gate='NOT REQUIRED / NOT RUN',full_reactor='NOT REQUIRED / NOT RUN',production_impact='NONE',diff_check_exit_code=subprocess.run(['git','diff','--check'],cwd=root).returncode)
assert checks['diff_check_exit_code']==0
(base/'delivery-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(base/'implementation.diff').write_text(command(['git','diff','--','app/pom.xml','scripts/testing/verify.py','scripts/testing/test_verification.py','docs/testing/Reactor_Verification_Policy.md']))
(base/'initial-observation.json').write_text(json.dumps(dict(head=initial,branch='feat/v3-architecture',worktree_clean=True,origin_after_fetch=initial,source='Observed by the initial git status/branch/rev-parse and fetch commands of this session; not a fabricated later git status'),indent=2)+'\n')
# Map explicitly: exclude all disposable checkouts/targets and dangerous link fixtures.
files={}
def add(path,name):
 if path.is_symlink(): return
 if path.is_dir():
  for p in sorted(path.rglob('*')):
   if p.is_file() and not p.is_symlink(): files[name+'/'+str(p.relative_to(path))]=p
 elif path.is_file(): files[name]=path
for n in ['foundation','fast','change','integration','failsafe-probe']:
 add(base/n,'resolution/'+n)
for p in base.iterdir():
 if p.name.startswith(('perf-','incremental-')): add(p,'resolution/'+p.name)
for n in ['campaigns.py','campaigns.json','build-probes.py','build-probes.log','performance.json','incremental.json','independent-checks.py','independent-checks.json','independent-checks.log','manifest-verification.json','reference-manifests.json','delivery-checks.json','initial-observation.json','remote-before-publication.txt','implementation.diff','verify-before.py.txt','package-evidence.py','unit-final.log','cli-tests-publication.log']:
 add(base/n,'resolution/'+n)
for n in ['foundation.console.log','fast.console.log','change.console.log','integration.console.log']:
 add(base/n,'resolution/'+n)
cli=base/'cli-tests-publication'
for p in cli.iterdir():
 if p.name!='checkout': add(p,'resolution/cli-tests/'+p.name)
before=base/'counter-audit'
for n in ['c4-cli-implicit-base-filter','c4-cli-replay','c4-cli-implicit-base-filter-console.log','c4-cli-replay-console.log','cli-replay-results.json']:
 add(before/'evidence'/n,'resolution/before/evidence/'+n)
add(before/'evidence/c2-foundation-docker/result.json','resolution/before/evidence/c2-foundation-docker/result.json')
add(before/'baseline-xml','resolution/before/baseline-xml')
add(before/'cli-replay-probe.py.txt','resolution/before/cli-replay-probe.py.txt')
for n in ['manifest.json','summary.json','README.md']:
 add(root/'docs/testing/evidence/verification-counter-audit-6d40ed17'/n,'resolution/reference-counter-audit/'+n)
for n in code: add(root/n,'resolution/source/'+n)
# Full bounded source snapshot allows offline module attribution/source review.
for n in command(['git','ls-files','app']).splitlines(): add(root/n,'resolution/source/'+n)
external=set()
for campaign in ['foundation','fast','change','integration']:
 external.update(load(base/campaign/'provenance.json')['external_sql_inputs'])
for n in sorted(external): add(root/n,'resolution/source/'+n)
for n in [
 'docs/testing/evidence/verification-resolution-33f02f45/resolution-evidence.tar.gz',
 'docs/testing/evidence/verification-resolution-33f02f45/manifest.json',
 'docs/testing/evidence/verification-independent-audit-d0927d94/audit-evidence.tar.gz',
 'docs/testing/evidence/verification-counter-audit-6d40ed17/counter-audit-evidence.tar.gz',
 'docs/testing/evidence/verification-counter-audit-6d40ed17/manifest.json',
 'docs/testing/evidence/verification-optimization/followup-builds.tar.gz']:
 add(root/n,'resolution/source/'+n)

# Preserve unsuccessful/exploratory work without promoting it to qualification.
for n in ['unit-first.log','unit-second.log','cli-tests.log','cli-tests-final.log','exploration-build-probes.log','exploration-perf-warm-before']:
 add(base/n,'resolution/exploration/'+n)
for folder in ['cli-tests','cli-tests-final']:
 for p in (base/folder).iterdir():
  if p.name!='checkout': add(p,'resolution/exploration/'+folder+'/'+p.name)
archive=out/'provenance-resolution-evidence.tar.gz'
with tarfile.open(archive,'w:gz',compresslevel=6) as bundle:
 for name,path in sorted(files.items()): bundle.add(path,arcname=name,recursive=False)
rows=load(base/'performance.json')
performance={}
for key in ['maven_seconds','discovery_seconds','wall_seconds']:
 before_values=[r[key] for r in rows if r['name'].startswith('before-')]; after_values=[r[key] for r in rows if r['name'].startswith('after-')]
 performance[key]=dict(before=before_values,after=after_values,median_delta=statistics.median(after_values)-statistics.median(before_values))
cli_records=load(cli/'cli-records.json')
summary=dict(repository='kartaguez/pocoma',branch='feat/v3-architecture',initial_sha=initial,audited_implementation='6d40ed17496709ce75175c4651dbaaaedc78343e',verdict='CLOSED WITH RESERVATIONS',scope=['FOUNDATION canonical','COMMAND/Identity FAST/CHANGE','Identity monolith integration','verification tooling'],source_sha256={n:sha(root/n) for n in code},campaigns=load(base/'campaigns.json'),independent_checks=load(base/'independent-checks.json'),cli_tests=dict(methods=10,seconds=83.819,verdict='PASS',records=[dict(name=x['name'],mode=x['mode'],exit_code=x['exit_code'],verdict=(x['result'] or {}).get('verdict','PREFLIGHT REFUSAL'),counts=(x['result'] or {}).get('counts'),issues=(x['result'] or {}).get('issues')) for x in cli_records]),unit_tests=dict(methods=30,seconds=.726,verdict='PASS'),performance=performance,incremental=load(base/'incremental.json'),failsafe_probe=load(base/'failsafe-probe/result.json'),before_counterexample=load(base/'counter-audit/evidence/cli-replay-results.json'),delivery_checks=checks,raw_archive_sha256=sha(archive),archive_members=len(files),I5='CLOSED BY HUMAN ACCEPTANCE WITH AVAILABILITY RESERVE; unchanged, not rerun',SPEC_10='NOT RUN; no certification',reservations=['Cooperative trusted producer; no cryptographic authentication against same-rights forgery','Current reviewed JUnit forms only; Failsafe CLI lifecycle not supported and explicitly refused','Single macOS environment, warm dependencies; performance observations are not statistical guarantees'])
(out/'summary.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
modified=['app/pom.xml','scripts/testing/verify.py','scripts/testing/test_verification.py','scripts/testing/test_verification_cli.py','docs/testing/Reactor_Verification_Policy.md','docs/v3/Verification_AUD_VERIFY_001_Provenance_Resolution.md']+[str((out/n).relative_to(root)) for n in ['README.md','summary.json','manifest.json','provenance-resolution-evidence.tar.gz']]
manifest=dict(initial_sha=initial,verdict=summary['verdict'],created_or_modified_files=modified,published_files={n:dict(bytes=(root/n).stat().st_size,sha256=sha(root/n)) for n in modified if not n.endswith('/manifest.json')},archive_member_count=len(files),archive_members={n:dict(bytes=p.stat().st_size,sha256=sha(p)) for n,p in sorted(files.items())},self_identity='manifest.json excluded from its own hashes; containing publication commit fixes exact bytes')
(out/'manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
# Reopen and verify the actual archive and published bytes, not the source map alone.
with tarfile.open(archive) as t:
 entries={e.name:e for e in t if e.isfile()}; assert set(entries)==set(manifest['archive_members'])
 for name,entry in entries.items():
  raw=t.extractfile(entry).read(); info=manifest['archive_members'][name]
  assert len(raw)==info['bytes'] and hashlib.sha256(raw).hexdigest()==info['sha256'],name
for name,info in manifest['published_files'].items(): assert (root/name).stat().st_size==info['bytes'] and sha(root/name)==info['sha256'],name
print(json.dumps(dict(archive_bytes=archive.stat().st_size,members=len(files),published_files=len(manifest['published_files']),verified=True),indent=2))

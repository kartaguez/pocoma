import java.util.*;
import com.kartaguez.pocoma.contracts.command.v3.*;
class CanonicalUtf8Proof {
 public static void main(String[] args) {
  var invalid=String.valueOf((char)0xd800);
  if(!Arrays.equals(AdmissionFields.canonical(Map.of("label",invalid)), AdmissionFields.canonical(Map.of("label","?")))) throw new AssertionError("Canonical alias not reproduced");
  if(!Arrays.equals(AdmissionProtection.frame(invalid),AdmissionProtection.frame("?"))) throw new AssertionError("Scope alias not reproduced");
  System.out.println("CONFIRMED: original intent canonicalization and scope framing alias an unpaired surrogate with question mark");
 }
}

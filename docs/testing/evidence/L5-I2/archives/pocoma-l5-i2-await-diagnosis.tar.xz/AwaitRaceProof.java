import java.time.Duration; import java.util.function.BooleanSupplier; import java.util.concurrent.atomic.AtomicInteger;
class AwaitRaceProof {
static void assertTrue(boolean value, String message) { if (!value) throw new AssertionError(message); }
    static void await(BooleanSupplier predicate, Duration timeout) throws Exception {
        long end = System.nanoTime() + timeout.toNanos();
        while (!predicate.getAsBoolean() && System.nanoTime() < end) Thread.sleep(5);
        assertTrue(predicate.getAsBoolean(), "runtime condition deadline");
    }


public static void main(String[] ignored) throws Exception {
var calls=new AtomicInteger(); boolean reproduced=false;
try { await(() -> calls.incrementAndGet()==1, Duration.ofSeconds(15)); }
catch(AssertionError expected) { reproduced=true; }
if(!reproduced || calls.get()!=2) throw new AssertionError("Original race not reproduced");
System.out.println("Original helper rejects a condition observed true: two reads, deterministic reproduction");
}}

#!/usr/bin/env bash
set -eu
proof=$1
workspace=$2
while ! test -f "$proof/resume-canonical.exit"; do sleep 3; done
python3 - "$proof" "$workspace" <<'PY'
from hashlib import sha256
import json,sys,shutil
from pathlib import Path
proof, workspace = map(Path,sys.argv[1:])
source = proof/'source'
before = json.loads((proof/'app-inputs.json').read_text())
changed = {
    'app/runtime-monolith/src/test/java/com/kartaguez/pocoma/InvitationReadPostgresTest.java',
    'app/runtime-monolith/src/test/java/com/kartaguez/pocoma/ReadWorkerResourcesPostgresTest.java',
}
after = {path: sha256((workspace/path).read_bytes()).hexdigest() for path in before}
assert {path for path in before if before[path] != after[path]} == changed
for path in changed:
    shutil.copy2(workspace/path, source/path)
assert all(sha256((source/path).read_bytes()).hexdigest() == expected for path,expected in after.items())
(proof/'app-inputs-final.json').write_text(json.dumps(after,indent=2)+'\n')
PY
reports="$proof/source/app/runtime-monolith/target/surefire-reports"
tar -C "$reports" -czf "$proof/old-monolith-xml.tar.gz" .
touch "$proof/replay-monolith.start"
cd "$proof/source/app"
command=(./mvnw --batch-mode --no-transfer-progress "-Dmaven.repo.local=$proof/maven-repository"
         -pl runtime-worker-materialize,runtime-web-write,runtime-web-read,architecture-tests
         -am -rf :pocoma-runtime-monolith test)
printf '%q ' "${command[@]}" > "$proof/replay-monolith.command"
printf '\n' >> "$proof/replay-monolith.command"
if "${command[@]}" > "$proof/replay-monolith.log" 2>&1; then code=0; else code=$?; fi
printf '%s\n' "$code" > "$proof/replay-monolith.exit"
exit "$code"

#!/usr/bin/env bash
set -u
proof=$1
run() {
  local phase=$1 exit_status
  shift
  printf '%q ' "$@" > "$proof/$phase.command"
  printf '\n' >> "$proof/$phase.command"
  if "$@" > "$proof/$phase.log" 2>&1; then exit_status=0; else exit_status=$?; fi
  printf '%s\n' "$exit_status" > "$proof/$phase.exit"
  return "$exit_status"
}
if test ! -d "$proof/maven-repository"; then
  cp -cR "$HOME/.m2/repository" "$proof/maven-repository" > "$proof/copy-repository.log" 2>&1 || exit 2
fi
cd "$proof/source/app" || exit 2
scope=runtime-worker-materialize,runtime-web-write,runtime-web-read,architecture-tests
repo="-Dmaven.repo.local=$proof/maven-repository"
run resume-install ./mvnw --batch-mode --no-transfer-progress "$repo" -pl "$scope" -am -DskipTests install || exit 2
run resume-worker-metrics ./mvnw --batch-mode --no-transfer-progress "$repo" -pl runtime-worker-process -am -Dtest=WorkerMetricsTest -Dsurefire.failIfNoSpecifiedTests=false test || exit 2
run resume-canonical ./mvnw --batch-mode --no-transfer-progress "$repo" -pl "$scope" -am -rf :pocoma-runtime-worker-materialize test

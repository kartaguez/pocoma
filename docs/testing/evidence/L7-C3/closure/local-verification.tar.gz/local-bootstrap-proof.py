import secrets
import subprocess
import time
from unittest.mock import patch

import bootstrap
import runtime

container = 'pocoma-c3-closure-' + secrets.token_hex(6)
image = 'postgres:17.6-alpine'
subprocess.run(['docker', 'run', '--name', container, '--pull=never', '--rm', '-d',
                '--network', 'none', '-e', 'POSTGRES_USER=pocoma',
                '-e', 'POSTGRES_HOST_AUTH_METHOD=trust', image], check=True,
               stdout=subprocess.DEVNULL)

try:
    for attempt in range(60):
        status = subprocess.run(['docker', 'exec', container, 'pg_isready',
                                 '-h', '127.0.0.1', '-U', 'pocoma'], capture_output=True)
        if status.returncode == 0:
            break
        time.sleep(1)
    else:
        raise RuntimeError('PostgreSQL did not start')

    with patch.object(runtime, 'pg_id', return_value=container):
        def sql(database, statement):
            return runtime.sql(None, None, database, statement)

        def fail_after_availability(database, statement):
            if database == 'pocoma_read' and 'CREATE TABLE public.pocoma_local_bootstrap' in statement:
                statement = statement.replace('CREATE TABLE public.pocoma_local_bootstrap',
                                              'SELECT 1/0;\nCREATE TABLE public.pocoma_local_bootstrap', 1)
            return sql(database, statement)

        passwords = {role: secrets.token_urlsafe(24) for role in bootstrap.ROLES}
        try:
            bootstrap.initialize(fail_after_availability, passwords)
        except RuntimeError as failure:
            assert str(failure).startswith('COMMAND-FAILED:docker')
        else:
            raise AssertionError('expected injected failure')
        assert sql('pocoma_read', "select to_regclass('v3_read.read_availability_event') is null"
                   " and to_regclass('public.pocoma_local_bootstrap') is null") == 't'
        print('Injected READ bootstrap failure rolled back V5 and the bootstrap marker')

        expected = bootstrap.initialize(sql, passwords)
        assert expected == bootstrap.initialize(sql, passwords)
        assert sql('pocoma_read', "select fingerprint from public.pocoma_local_bootstrap") == expected
        assert sql('pocoma_read', "select count(*) from v3_read.read_availability_counter") == '8'
        assert sql('pocoma_read', "select v3_read.read_availability_schema_valid() and"
                   " v3_read.read_availability_valid()") == 't'
        assert sql('pocoma_read', """
            select has_table_privilege('pocoma_read', 'v3_read.read_availability_event', 'insert')
               and not has_table_privilege('pocoma_read', 'v3_read.read_availability_event', 'delete')
               and not has_table_privilege('pocoma_read_http', 'v3_read.read_availability_event', 'select')
               and not has_function_privilege('pocoma_read_http',
                   'v3_read.read_current_availability_page(text,bigint,integer)', 'execute')
            """) == 't'
        print(sql('pocoma_read', 'show server_version'))
        print('Fresh bootstrap and repeat passed: eight families, matching marker, valid catalog and isolated grants')

        statements = '''
            begin;
            set local role pocoma_read;
            set local search_path to v3_read, public;
            insert into read_command_result values (
                '00000000-0000-0000-0000-000000000001', 'CreatePot', 'fixture', 'actor',
                '00000000-0000-0000-0000-000000000002', 'CHANGED', 1, null);
            with allocated as (
                update read_availability_counter set position = position + 1
                where family = 'COMMAND_RESULT_AVAILABLE' returning family, position
            )
            insert into read_availability_event(family, position, event_id, projection_key)
            select family, position, '00000000-0000-0000-0000-000000000003',
                   '00000000-0000-0000-0000-000000000001' from allocated;
            insert into read_pot_visibility_state values ('00000000-0000-0000-0000-000000000002', 0);
            update read_pot_visibility_state set materialized_version = 1;
            with allocated as (
                update read_availability_counter set position = position + 1
                where family = 'POT_VISIBILITY_CHANGED' returning family, position
            )
            insert into read_current_availability(family, projection_key, logical_version, position)
            select family, '00000000-0000-0000-0000-000000000002', 1, position from allocated
            on conflict (family, projection_key) do update
            set logical_version = excluded.logical_version, position = excluded.position;
            commit;
        '''
        sql('pocoma_read', statements)
        assert sql('pocoma_read', 'select v3_read.read_availability_valid()') == 't'
        assert sql('pocoma_read', 'select sum(position) from v3_read.read_availability_counter') == '2'
        print('Canonical PostgreSQL triggers accept both grouped statement shapes in a guarded-role transaction')

        sql('pocoma_read', '''
            begin;
            set local role pocoma_read;
            set local search_path to v3_read, public;
            update read_pot_visibility_state set materialized_version = 2;
            with allocated as (
                update read_availability_counter set position = position + 1
                where family = 'POT_VISIBILITY_CHANGED' returning family, position
            )
            insert into read_current_availability(family, projection_key, logical_version, position)
            select family, '00000000-0000-0000-0000-000000000002', 2, position from allocated
            on conflict (family, projection_key) do update
            set logical_version = excluded.logical_version, position = excluded.position;
            commit;
        ''')
        assert sql('pocoma_read', '''select logical_version || ':' || position
                                     from v3_read.read_current_availability''') == '2:2'
        plan = sql('pocoma_read', '''
            set role pocoma_read;
            set search_path to v3_read, public;
            set plan_cache_mode = force_generic_plan;
            prepare lookup(text, uuid, bigint) as
              select exists (select from read_availability_effects
                             where family = $1 and projection_key = $2 and logical_version = $3);
            explain (analyze, costs off, timing off) execute lookup('POT_VISIBILITY_CHANGED',
                '00000000-0000-0000-0000-000000000002', 2);
            prepare unversioned_lookup(text, uuid) as
              select exists (select from read_availability_effects
                             where family = $1 and projection_key = $2 and logical_version is null);
            explain (analyze, costs off, timing off) execute unversioned_lookup('IDENTITY_REQUEST_RESULT_AVAILABLE',
                '00000000-0000-0000-0000-000000000009');
        ''')
        scans = [line for line in plan.splitlines() if ' on read_' in line and 'loops=' in line
                 and 'Bitmap Index Scan' not in line]
        assert len(scans) == 2 and ' on read_pot_visibility_state ' in scans[0] \
               and ' on read_identity_request_result ' in scans[1], plan
        assert 'One-Time Filter:' in plan and '(never executed)' in plan, plan
        print(plan)
finally:
    subprocess.run(['docker', 'stop', container], stdout=subprocess.DEVNULL, check=True)

import re
import sys
import unicodedata
from pathlib import Path
from urllib.parse import unquote, urlsplit

link = re.compile(r"(?<!\\)\]\(<?((?:[^\s()<>]|\([^()]*\))+)>?(?:\s+\"[^\"]*\")?\)")
heading = re.compile(r"^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$")
html_anchor = re.compile(r'<(?:a|[^>]+)\s+[^>]*?(?:name|id)=["\']([^"\']+)["\']', re.I)
cache = {}


def anchors(path):
    if path in cache:
        return cache[path]
    content = path.read_text()
    values = set(html_anchor.findall(content))
    counts = {}
    fenced = False
    for line in content.splitlines():
        if re.match(r'^\s*(```|~~~)', line):
            fenced = not fenced
            continue
        if fenced or (match := heading.match(line)) is None:
            continue
        text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', match[1].strip().lower())
        text = ''.join(c for c in text if not unicodedata.category(c).startswith(('P', 'S'))
                       or c in '-_')
        slug = re.sub(r'\s', '-', text)
        count = counts.get(slug, 0)
        values.add(f'{slug}-{count}' if count else slug)
        counts[slug] = count + 1
    cache[path] = values
    return values


errors = []
checked = 0
for filename in sys.argv[1:]:
    source = Path(filename)
    fenced = False
    for number, line in enumerate(source.read_text().splitlines(), 1):
        if re.match(r'^\s*(```|~~~)', line):
            fenced = not fenced
            continue
        if fenced:
            continue
        for match in link.finditer(line):
            target = urlsplit(match[1])
            if target.scheme or target.netloc:
                continue
            checked += 1
            path = (source.parent / unquote(target.path)).resolve() if target.path else source.resolve()
            fragment = unquote(target.fragment)
            if not path.exists():
                errors.append(f'{source}:{number}: missing {match[1]}')
            elif fragment and path.suffix.lower() == '.md' and fragment not in anchors(path):
                errors.append(f'{source}:{number}: missing anchor {match[1]}')
            elif (lines := re.fullmatch(r'L(\d+)(?:-L(\d+))?', fragment)) and path.is_file():
                if int(lines[2] or lines[1]) > len(path.read_text().splitlines()):
                    errors.append(f'{source}:{number}: line anchor outside file {match[1]}')
print(f'{checked} repository links checked; {len(errors)} errors')
print('\n'.join(errors))
sys.exit(bool(errors))

#!/bin/bash
set -euo pipefail
gate=$(cd "$(dirname "$0")" && pwd -P)
cd "$gate/source"
fingerprint() {
  find ./app ./scripts ./docker ./docker-compose.v3-five-runtimes.yml ./pocoma-local \
    ./docs/archive/v3-sql-migrations ./docs/v3/L7_Target_Modular_Architecture_and_Migration_Plan.md \
    ./docs/testing/evidence/L7-full-execution/sql-migration-ownership.json \
    ./docs/testing/evidence/L2-I1/routing-vectors.csv \
    ./docs/testing/evidence/L2-I4/Performance-inputs.json \
    ./docs/testing/evidence/L2-I5-audit-remediation/temporal-contract-v1.properties \
    ./docs/testing/evidence/L2-I5-temporal-v2/temporal-contract-v2.properties \
    ./docs/testing/evidence/L2-I5-temporal-final/temporal-contract-v3.properties -type d \( -name target -o -name node_modules \) -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 shasum -a 256
}
test "$(cat "$gate/canonical.exit")" = 1
cmp "$gate/inputs.sha256" "$gate/inputs-after.sha256"
cmp "$gate/bruno-locked/package-lock.json" scripts/bruno-v3/package-lock.json
mv "$gate/bruno-locked/node_modules" scripts/bruno-v3/node_modules
mkdir "$gate/bruno-before-npm" "$gate/bruno-resume-output"
for dir in "$gate"/bruno-b2* "$gate"/bruno-b4; do
  if [ -d "$dir" ]; then mv "$dir" "$gate/bruno-before-npm/"; fi
done
bruno_fingerprint() {
  (cd scripts/bruno-v3
   readlink node_modules/.bin/bru
   find node_modules -type f -print0 | LC_ALL=C sort -z | xargs -0 shasum -a 256)
}
fingerprint > "$gate/resume-inputs-before.sha256"
cmp "$gate/inputs.sha256" "$gate/resume-inputs-before.sha256"
bruno_fingerprint > "$gate/bruno-before.sha256"
cd app
run() {
  local label=$1
  shift
  local provenance=$label
  if [ "$label" = effective ]; then provenance=canonical; fi
  local -a command=(./mvnw --batch-mode --no-transfer-progress "-Dmaven.repo.local=$gate/maven-repository"
    "-Dpocoma.verification.id=${gate##*.}-v5-$provenance" "-Dpocoma.verification.reports=$gate/$provenance-reports" "$@")
  printf '%q ' "${command[@]}" > "$gate/$label.command"
  printf '\n' >> "$gate/$label.command"
  date -u '+%FT%TZ' > "$gate/$label.start"
  local result=0
  "${command[@]}" > "$gate/$label.log" 2>&1 || result=$?
  printf '%s\n' "$result" > "$gate/$label.exit"
  date -u '+%FT%TZ' > "$gate/$label.end"
  return "$result"
}
anchors=runtime-worker-materialize,runtime-web-write,runtime-web-read,runtime-worker-process,runtime-monolith,architecture-tests
run install -pl "$anchors" -am -DskipTests install
rc=0
run resume -pl "$anchors" -am -rf :pocoma-runtime-monolith test || rc=$?
cd "$gate/source"
fingerprint > "$gate/resume-inputs-after.sha256"
cmp "$gate/inputs.sha256" "$gate/resume-inputs-after.sha256"
bruno_fingerprint > "$gate/bruno-after.sha256"
cmp "$gate/bruno-before.sha256" "$gate/bruno-after.sha256"
for dir in "$gate"/bruno-b2* "$gate"/bruno-b4; do
  if [ -d "$dir" ]; then mv "$dir" "$gate/bruno-resume-output/"; fi
done
exit "$rc"

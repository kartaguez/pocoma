#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/source"
container=$(docker run --rm -d --pull=never --network none -e POSTGRES_USER=pocoma \
  -e POSTGRES_DB=pocoma -e POSTGRES_PASSWORD=pocoma-local-only postgres:17.6-alpine)
trap 'docker stop "$container" >/dev/null' EXIT
for attempt in {1..30}; do
  if docker exec "$container" pg_isready -h 127.0.0.1 -U pocoma -d pocoma >/dev/null; then break; fi
  sleep 1
done
python3 -B scripts/operations/setup-v3-database.py --postgres-container "$container"
query() {
  docker exec "$container" psql -XAtq -U pocoma -d pocoma_read -v ON_ERROR_STOP=1 -c "$1"
}
test "$(query 'show server_version')" = '17.6'
test "$(query "
  select has_table_privilege('pocoma_read_http', 'v3_read.read_command_result', 'SELECT')
     and has_table_privilege('pocoma_read_http', 'v3_read.read_identity_request_result', 'SELECT')
     and not has_table_privilege('pocoma_read_http', 'v3_read.read_availability_event', 'SELECT')
     and has_table_privilege('pocoma_read_status', 'public.read_maintenance_state', 'SELECT')
     and not has_table_privilege('pocoma_read_status', 'v3_read.read_command_result', 'SELECT');
")" = t
printf '%s\n' 'PostgreSQL 17.6: HTTP query, status and publication metadata ACL checks passed.'
query 'drop function v3_read.read_current_availability_page(text,bigint,integer);'
set +e
output=$(python3 -B scripts/operations/setup-v3-database.py --postgres-container "$container" 2>&1)
setup_exit=$?
set -e
printf '%s\nsetup exit=%s\n' "$output" "$setup_exit"
test "$setup_exit" = 1
case "$output" in
  *'V3 PostgreSQL initialization complete.'*) exit 1 ;;
  *'Incomplete READ V5 schema; repair by exclusive READ reconstruction.'*) ;;
  *) exit 1 ;;
esac
test "$(query "select to_regclass('v3_read.read_availability_event') is not null
 and to_regprocedure('v3_read.read_current_availability_page(text,bigint,integer)') is null
 and (select count(*) from v3_read.consumption_routing_contract) = 7;")" = t
printf '%s\n' 'Partial V5 catalog refused with intact READ routing.'

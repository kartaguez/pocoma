"""Check exact source-derived identities and archive the individually attributed executions."""
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import tarfile
import xml.etree.ElementTree as ET

run = Path(__file__).resolve().parent
out = Path(sys.argv[1])
out.mkdir(parents=True, exist_ok=True)
expected = json.loads((run / "inventory.json").read_text())
spec = importlib.util.spec_from_file_location("selector", run / "source/scripts/testing/verify.py")
selector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(selector)

def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()

def summarize(directory, label, invocation_id):
    report_root = directory / (label + "-reports")
    reports = sorted(report_root.glob("*/surefire-reports/TEST-*.xml"))
    modules, counts = set(), dict(tests=0, failures=0, errors=0, skipped=0)
    for report in reports:
        module = report.parent.parent.name
        suite = ET.parse(report).getroot()
        selector._check_provenance_properties(suite, dict(invocation_id=invocation_id), module, "surefire")
        modules.add(module)
        cases = suite.findall("testcase")
        actual = dict(tests=len(cases), failures=sum(c.find("failure") is not None for c in cases),
                      errors=sum(c.find("error") is not None for c in cases),
                      skipped=sum(c.find("skipped") is not None for c in cases))
        for key, count in actual.items():
            assert int(suite.get(key, "0")) == count, report
            counts[key] += count
    counts["passed"] = counts["tests"] - sum(counts[k] for k in ("failures", "errors", "skipped"))
    result = dict(command=(directory / (label + ".command")).read_text().strip(),
                  exit=int((directory / (label + ".exit")).read_text()),
                  start=(directory / (label + ".start")).read_text().strip(),
                  end=(directory / (label + ".end")).read_text().strip(),
                  invocation=invocation_id, modules_with_xml=len(modules), xml=len(reports), counts=counts,
                  inputs_sha256=digest(directory / "inputs.sha256"))
    return reports, result

old = run / "incomplete-checkout"
focused_reports, focused = summarize(run, "focused", "dnZDLX-focused")
focused["inputs_sha256"] = digest(old / "inputs.sha256")
original_reports, original = summarize(old, "canonical", "dnZDLX-canonical")
original["diagnosis"] = "The isolated checkout omitted the tracked L2-I1/routing-vectors.csv fixture."
second_dir = run / "missing-discovery-fixture"
second_reports, second = summarize(second_dir, "canonical", "dnZDLX-v2-canonical")
second["diagnosis"] = "The isolated checkout omitted the tracked L2-I4/Performance-inputs.json fixture. Maven was stopped after DiscoveryPostgresTest had logged the errors."
third_dir = run / "complete-before-readiness-fix"
third_reports, third = summarize(third_dir, "canonical", "dnZDLX-v3-canonical")
third["diagnosis"] = "The fixture reached its first JDBC connect before the mapped PostgreSQL endpoint was ready; no SQL had run. Fixture startup now uses Testcontainers JDBC readiness."
readiness_reports, readiness = summarize(run, "readiness", "dnZDLX-v4-readiness")
canonical_reports, canonical = summarize(run, "canonical", "dnZDLX-v4-canonical")
resumed_reports, resumed = summarize(run, "resume", "dnZDLX-v5-resume")
canonical["diagnosis"] = "The isolated checkout was missing the npm-locked Bruno binary required by Monolith's JUnit Bruno corpus tests."
canonical_log = (run / "canonical.log").read_text(errors="replace")
def module_status(log):
    return {name: status for name, status in re.findall(r"^\[INFO\] (pocoma\S*) +(?:\.+ +)?(SUCCESS|SKIPPED|FAILURE)\b", log, re.M)}
canonical["reactor_summary"] = module_status(canonical_log)
original["reactor_summary"] = module_status((old / "canonical.log").read_text(errors="replace"))
second["reactor_summary"] = module_status((second_dir / "canonical.log").read_text(errors="replace"))
third["reactor_summary"] = module_status((third_dir / "canonical.log").read_text(errors="replace"))
canonical["reactor_projects"] = len(expected["modules"])
canonical["postgresql_jdbc_observed"] = sorted(set(re.findall(r"\(PostgreSQL ([\d.]+)\)", canonical_log)))

resumed["reactor_summary"] = module_status((run / "resume.log").read_text(errors="replace"))
resumed["postgresql_jdbc_observed"] = sorted(set(re.findall(
    r"\(PostgreSQL ([\d.]+)\)", (run / "resume.log").read_text(errors="replace"))))
resumed_modules = {"pocoma-runtime-monolith", "pocoma-architecture-tests"}
retained_modules = set(expected["modules"]) - resumed_modules
assert not expected["issues"]
issues = []

def validate_selection(paths, label, invocation, required_modules, exit_code):
    identities = {cls: methods for cls, methods in expected["expected"].items()
                  if expected["expected_modules"][cls] in required_modules}
    reports = [(str(Path("reports") / path.relative_to(run / (label + "-reports"))), path.read_bytes())
               for path in paths]
    assessment = selector.assess(reports, identities, exit_code, False,
                                dict(invocation_id=invocation,
                                     expected_modules=expected["expected_modules"]))
    issues.extend(assessment["issues"])
    return assessment["counts"], len(identities)

if canonical["exit"] != 1 or set(canonical["reactor_summary"]) != set(expected["modules"]):
    issues.append("The original full command did not end with the documented reactor failure")
if any(canonical["reactor_summary"].get(name) != "SUCCESS" for name in retained_modules):
    issues.append("An original upstream module lacks a Maven SUCCESS receipt")
if (canonical["reactor_summary"].get("pocoma-runtime-monolith") != "FAILURE"
        or canonical["reactor_summary"].get("pocoma-architecture-tests") != "SKIPPED"):
    issues.append("The original Monolith/architecture summary is unexpected")
if resumed["exit"] or resumed["reactor_summary"] != dict.fromkeys(resumed_modules, "SUCCESS"):
    issues.append("The unfiltered Monolith/architecture resume failed or is incomplete")
if int((run / "install.exit").read_text()) or int((run / "npm.exit").read_text()):
    issues.append("The isolated artifact or Bruno installation failed")

retained = [path for path in canonical_reports if path.parent.parent.name in retained_modules]
upstream_counts, upstream_suites = validate_selection(
    retained, "canonical", canonical["invocation"], retained_modules, 0)
suffix_counts, suffix_suites = validate_selection(
    resumed_reports, "resume", resumed["invocation"], resumed_modules, resumed["exit"])
before = run / "inputs.sha256"
for name in ("inputs-after.sha256", "resume-inputs-before.sha256", "resume-inputs-after.sha256"):
    path = run / name
    if not path.is_file() or before.read_bytes() != path.read_bytes():
        issues.append(f"The source fingerprint differs or is missing: {name}")
if (run / "bruno-before.sha256").read_bytes() != (run / "bruno-after.sha256").read_bytes():
    issues.append("The installed Bruno bytes changed during the resume")
accepted_counts = {k: upstream_counts[k] + suffix_counts[k] for k in upstream_counts}
accepted_counts["passed"] = accepted_counts["tests"] - sum(accepted_counts[k] for k in ("failures", "errors", "skipped"))
result = dict(reactor_projects=len(expected["modules"]), expected_tests=sum(map(len,expected["expected"].values())),
              tests_expected_from_sources=True, counts=accepted_counts, upstream_counts=upstream_counts,
              suffix_counts=suffix_counts, upstream_suites=upstream_suites, suffix_suites=suffix_suites,
              inputs_sha256=digest(before), inputs_entries=len(before.read_text().splitlines()),
              upstream_modules=sorted(retained_modules), suffix_modules=sorted(resumed_modules),
              bruno_inventory_sha256=digest(run / "bruno-before.sha256"),
              issues=issues, verdict="INCONCLUSIVE" if issues else "PASS_WITH_RESERVATIONS")

paths = []
for attempt, labels, reports_dir in [
    (old, ("canonical", "effective"), ("canonical-reports",)),
    (second_dir, ("canonical", "effective"), ("canonical-reports",)),
    (third_dir, ("canonical", "effective"), ("canonical-reports",)),
    (run, ("canonical", "effective", "focused", "readiness", "install", "resume", "npm"),
     ("canonical-reports", "focused-reports", "readiness-reports", "resume-reports")),
]:
    for label in labels:
        paths.extend(attempt.glob(label + ".*"))
    for directory in reports_dir:
        paths.extend(p for p in (attempt / directory).rglob("*") if p.is_file())
    paths.extend(attempt.glob("inputs*.sha256"))
    paths.extend(attempt.glob("inventory.json"))
paths.extend(run / name for name in (
    "head.txt", "toolchain.txt", "canonical-toolchain.txt", "inventory.py", "collect.py",
    "run.sh", "run-canonical.sh", "run-complete.sh", "run-final.sh", "operations-replay.log", "operations-replay.exit",
    "check-partial-catalog.sh", "partial-catalog.log", "partial-catalog.exit", "worktree-inputs-check.log",
    "run-resume.sh", "resume-inputs-before.sha256", "resume-inputs-after.sha256", "bruno-toolchain.txt",
    "bruno-before.sha256", "bruno-after.sha256",
))
projection_target = run / "source/app/runtime-worker-materialize/target"
paths.extend(path for path in projection_target.glob("*evidence*/**/*") if path.is_file())
monolith_target = run / "source/app/runtime-monolith/target"
paths.extend(path for path in monolith_target.glob("*evidence*/**/*") if path.is_file())
for folder in ("bruno-before-npm", "bruno-resume-output"):
    paths.extend(path for path in run.glob(folder + "/**/*") if path.is_file())
files = {str(p.relative_to(run)): digest(p) for p in sorted(set(paths))}
archive = out / "campaign.tar.gz"
with tarfile.open(archive, "w:gz") as bundle:
    for relative in files:
        bundle.add(run / relative, arcname=relative, recursive=False)
with tarfile.open(archive, "r:gz") as bundle:
    assert len(bundle.getmembers()) == len(files)
    for member in bundle.getmembers():
        with bundle.extractfile(member) as stream:
            assert hashlib.file_digest(stream, "sha256").hexdigest() == files[member.name]
receipt = dict(tested_head=(run / "head.txt").read_text().strip(),
               qualification=result, canonical=canonical, resume=resumed, initial_incomplete_checkout=original,
               second_incomplete_checkout=second, before_readiness_fix=third, focused=focused, readiness=readiness,
               install_exit=int((run / "install.exit").read_text()), npm_exit=int((run / "npm.exit").read_text()),
               toolchain=(run / "canonical-toolchain.txt").read_text().splitlines(),
               archive_sha256=digest(archive), archived_files_sha256=files)
(out / "qualification.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
(out / "inputs.sha256").write_bytes(before.read_bytes())
print(json.dumps({k:v for k,v in result.items() if k not in ("issues", "upstream_modules")}, indent=2))
print("\n".join(issues[:25]))
sys.exit(bool(issues))

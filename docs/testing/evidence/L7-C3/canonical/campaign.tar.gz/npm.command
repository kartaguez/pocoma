npm ci --ignore-scripts --no-audit --no-fund --cache /private/tmp/pocoma-c3-canonical.dnZDLX/npm-cache

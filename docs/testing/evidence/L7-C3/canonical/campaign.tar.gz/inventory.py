"""Derive canonical Surefire expectations from the captured effective reactor and checkout."""
from collections import Counter
import importlib.util
import json
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

run = Path(__file__).resolve().parent
source = run / "source"
spec = importlib.util.spec_from_file_location("selector", source / "scripts/testing/verify.py")
selector = importlib.util.module_from_spec(spec)
spec.loader.exec_module(selector)
root = ET.parse(run / "effective.xml").getroot()
projects = list(root) if root.tag == "projects" else [root]
model_id = run.name.rsplit(".", 1)[1] + "-v4-canonical"
definition = dict(filtered=False, expected={}, invocation_id=model_id, reports_root=str(run / "canonical-reports"))
module_paths = {ET.parse(p).getroot().findtext("m:artifactId", "", selector.NS): p.parent
                for p in (source / "app").glob("*/pom.xml")}
model, discovered, owners, issues = [], {}, {}, []
state = (definition, selector.sources(source), discovered, owners, issues)
for project in projects:
    selector._scan_project(project, module_paths, state, model)
selector._reconcile_expected(definition, discovered, issues)
modules = [project.findtext("m:artifactId", "", selector.NS) for project in projects]
receipt = dict(modules=modules, expected=discovered, expected_modules=owners, issues=issues)
(run / "inventory.json").write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n")
print(len(modules), len(discovered), sum(map(len, discovered.values())))
for issue in issues:
    print(issue)
sys.exit(bool(issues))

#!/bin/bash
set -euo pipefail
gate=$(cd "$(dirname "$0")" && pwd -P)
cd "$gate/source"
fingerprint() {
  find . -type d -name target -prune -o -type f -print0 | LC_ALL=C sort -z | xargs -0 shasum -a 256
}
fingerprint > "$gate/inputs.sha256"
shasum -a 256 "$gate/inputs.sha256" > "$gate/inputs.digest"
cd app
for variable in MAVEN_ARGS MAVEN_OPTS JAVA_TOOL_OPTIONS JDK_JAVA_OPTIONS _JAVA_OPTIONS MAVEN_BASEDIR MAVEN_PROJECTBASEDIR; do
  if [ -n "${!variable:-}" ]; then
    printf 'Unexpected nonempty setting: %s\n' "$variable" >&2
    exit 2
  fi
done
{
  ./mvnw --version
  docker version --format '{{.Server.Version}}'
  for image in postgres:17-alpine postgres:16-alpine; do
    docker image inspect --format '{{.Id}} {{json .RepoDigests}} {{.Architecture}}' "$image"
    docker run --rm --pull=never --network none --entrypoint postgres "$image" --version
  done
} > "$gate/toolchain.txt" 2>&1
run() {
  local label=$1
  shift
  local -a command=(./mvnw --batch-mode --no-transfer-progress "-Dmaven.repo.local=$gate/maven-repository"
    "-Dpocoma.verification.id=${gate##*.}-$label" "-Dpocoma.verification.reports=$gate/$label-reports" "$@")
  printf '%q ' "${command[@]}" > "$gate/$label.command"
  printf '\n' >> "$gate/$label.command"
  date -u '+%FT%TZ' > "$gate/$label.start"
  local result=0
  "${command[@]}" > "$gate/$label.log" 2>&1 || result=$?
  printf '%s\n' "$result" > "$gate/$label.exit"
  date -u '+%FT%TZ' > "$gate/$label.end"
  return "$result"
}
run focused -pl runtime-worker-materialize -am '-Dtest=ReadParticipantsIntegrationPostgresTest#participantConformance+l73_allReadParticipantsRetainUncertainCapacityAndExactEffects' -Dsurefire.failIfNoSpecifiedTests=false test
anchors=runtime-worker-materialize,runtime-web-write,runtime-web-read,runtime-worker-process,runtime-monolith,architecture-tests
run effective -pl "$anchors" -am "-Doutput=$gate/effective.xml" help:effective-pom
gate_result=0
run canonical -pl "$anchors" -am test || gate_result=$?
cd "$gate/source"
fingerprint > "$gate/inputs-after.sha256"
cmp "$gate/inputs.sha256" "$gate/inputs-after.sha256"
exit "$gate_result"

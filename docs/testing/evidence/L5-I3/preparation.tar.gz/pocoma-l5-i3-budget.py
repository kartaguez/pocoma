import json,subprocess,time,sys,signal,os
from pathlib import Path
kind,campaign=sys.argv[1:3]
suffix=sys.argv[3] if len(sys.argv)>3 else ''
ledger=Path('/tmp/pocoma-l5-i3-budget.json')
rows=json.loads(ledger.read_text()) if ledger.exists() else []
limits={'FAST':120,'PG':480,'BRUNO':600}
if any(r['seconds']>limits[r['kind']] for r in rows) or sum(r['seconds'] for r in rows)>=1200:
 raise SystemExit('Campaign launches suspended: prior envelope exhausted')
seconds=min(limits[kind]-sum(r['seconds'] for r in rows if r['kind']==kind),1200-sum(r['seconds'] for r in rows))
if seconds<=0:raise SystemExit('Campaign envelope exhausted')
output=Path('/tmp/pocoma-l5-i3-'+campaign.lower()+suffix)
argv=['python3','-B','scripts/testing/verify.py','FAST' if kind=='FAST' else 'INTEGRATION',campaign,'--output',str(output)]
start=time.monotonic()
with output.with_suffix('.log').open('w') as log:
 proc=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT)
 try:code=proc.wait(timeout=seconds)
 except subprocess.TimeoutExpired:
  proc.send_signal(signal.SIGINT)
  try:proc.wait(timeout=10)
  except subprocess.TimeoutExpired:raise SystemExit('Physical cleanup unresolved; stop all launches')
  code=124
row={'kind':kind,'campaign':campaign,'command':argv,'seconds':time.monotonic()-start,'exit':code,'output':str(output)}
rows.append(row);ledger.write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row));sys.exit(code)

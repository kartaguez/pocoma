package com.kartaguez.pocoma.runtime.event.consumption;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

/** Shared deployment properties for the canonical Event worker. */
@ConfigurationProperties("pocoma.event-consumption")
public class EventConsumptionProperties {
	private boolean enabled;
	private List<String> projectionTypes = new ArrayList<>();
	private int segmentIndex;
	private int segmentCount = 1;
	private String workerId = "event-consumption-worker";
	private Duration claimLease = Duration.ofSeconds(30);
	private int maxCandidatesInspected = 100;
	private int maxConsumptionsExecuted = 10;
	private Duration pollInterval = Duration.ofSeconds(1);
	private Duration runtimeFailureBackoff = Duration.ofSeconds(5);

	public boolean isEnabled() { return enabled; }
	public void setEnabled(boolean enabled) { this.enabled = enabled; }
	public List<String> getProjectionTypes() { return projectionTypes; }
	public void setProjectionTypes(List<String> projectionTypes) { this.projectionTypes = projectionTypes; }
	public int getSegmentIndex() { return segmentIndex; }
	public void setSegmentIndex(int segmentIndex) { this.segmentIndex = segmentIndex; }
	public int getSegmentCount() { return segmentCount; }
	public void setSegmentCount(int segmentCount) { this.segmentCount = segmentCount; }
	public String getWorkerId() { return workerId; }
	public void setWorkerId(String workerId) { this.workerId = workerId; }
	public Duration getClaimLease() { return claimLease; }
	public void setClaimLease(Duration claimLease) { this.claimLease = claimLease; }
	public int getMaxCandidatesInspected() { return maxCandidatesInspected; }
	public void setMaxCandidatesInspected(int value) { this.maxCandidatesInspected = value; }
	public int getMaxConsumptionsExecuted() { return maxConsumptionsExecuted; }
	public void setMaxConsumptionsExecuted(int value) { this.maxConsumptionsExecuted = value; }
	public Duration getPollInterval() { return pollInterval; }
	public void setPollInterval(Duration pollInterval) { this.pollInterval = pollInterval; }
	public Duration getRuntimeFailureBackoff() { return runtimeFailureBackoff; }
	public void setRuntimeFailureBackoff(Duration value) { this.runtimeFailureBackoff = value; }
}

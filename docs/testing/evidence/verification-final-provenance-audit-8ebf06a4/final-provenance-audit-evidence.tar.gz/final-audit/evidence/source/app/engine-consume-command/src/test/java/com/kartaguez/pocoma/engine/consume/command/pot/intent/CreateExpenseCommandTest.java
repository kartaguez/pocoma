package com.kartaguez.pocoma.engine.consume.command.pot.intent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Set;
import java.util.UUID;
import java.time.LocalDate;

import org.junit.jupiter.api.Test;

class CreateExpenseCommandTest {

	@Test
	void createsCreateExpenseCommand() {
		UUID potId = UUID.randomUUID();
		UUID payerId = UUID.randomUUID();
		CreateExpenseCommand.ExpenseShareInput share =
				new CreateExpenseCommand.ExpenseShareInput(UUID.randomUUID(), 1, 2);

		LocalDate date = LocalDate.parse("2026-01-01");
		CreateExpenseCommand command = new CreateExpenseCommand(potId, payerId, 42, 1, "Dinner", date, Set.of(share), 3);

		assertEquals(potId, command.potId());
		assertEquals(payerId, command.payerId());
		assertEquals("Dinner", command.label());
		assertEquals(date, command.date());
		assertEquals(Set.of(share), command.shares());
		assertEquals(3, command.observedVersion());
	}

	@Test
	void rejectsMissingBusinessDate() {
		assertThrows(NullPointerException.class, () -> new CreateExpenseCommand(
				UUID.randomUUID(), UUID.randomUUID(), 42, 1, "Dinner", null,
				Set.of(new CreateExpenseCommand.ExpenseShareInput(UUID.randomUUID(), 1, 1)), 3));
	}

	@Test
	void rejectsEmptyShares() {
		assertThrows(IllegalArgumentException.class, () -> new CreateExpenseCommand(
				UUID.randomUUID(),
				UUID.randomUUID(),
				42,
				1,
				"Dinner",
				LocalDate.parse("2026-01-01"),
				Set.of(),
				3));
	}

	@Test
	void rejectsInvalidExpectedVersion() {
		assertThrows(IllegalArgumentException.class, () -> new CreateExpenseCommand(
				UUID.randomUUID(),
				UUID.randomUUID(),
				42,
				1,
				"Dinner",
				LocalDate.parse("2026-01-01"),
				Set.of(new CreateExpenseCommand.ExpenseShareInput(UUID.randomUUID(), 1, 1)),
				0));
	}

	@Test
	void rejectsNegativeAmount() {
		assertThrows(IllegalArgumentException.class, () -> new CreateExpenseCommand(
				UUID.randomUUID(),
				UUID.randomUUID(),
				-1,
				1,
				"Dinner",
				LocalDate.parse("2026-01-01"),
				Set.of(new CreateExpenseCommand.ExpenseShareInput(UUID.randomUUID(), 1, 1)),
				3));
	}

	@Test
	void rejectsZeroAmountDenominator() {
		assertThrows(IllegalArgumentException.class, () -> new CreateExpenseCommand(
				UUID.randomUUID(),
				UUID.randomUUID(),
				42,
				0,
				"Dinner",
				LocalDate.parse("2026-01-01"),
				Set.of(new CreateExpenseCommand.ExpenseShareInput(UUID.randomUUID(), 1, 1)),
				3));
	}

	@Test
	void rejectsZeroExpenseShareWeight() {
		assertThrows(IllegalArgumentException.class, () -> new CreateExpenseCommand.ExpenseShareInput(
				UUID.randomUUID(),
				0,
				1));
	}

	@Test
	void rejectsNegativeExpenseShareWeight() {
		assertThrows(IllegalArgumentException.class, () -> new CreateExpenseCommand.ExpenseShareInput(
				UUID.randomUUID(),
				-1,
				2));
	}

	@Test
	void rejectsZeroExpenseShareWeightDenominator() {
		assertThrows(IllegalArgumentException.class, () -> new CreateExpenseCommand.ExpenseShareInput(
				UUID.randomUUID(),
				1,
				0));
	}
}

package com.kartaguez.pocoma.engine.consume.command.pot.intent;

import java.time.LocalDate;
import java.util.Objects;
import java.util.UUID;

import com.kartaguez.pocoma.engine.consume.command.model.Command;

import com.kartaguez.pocoma.domain.pot.value.Amount;
import com.kartaguez.pocoma.domain.pot.value.Fraction;

public record UpdateExpenseDetailsCommand(
		UUID expenseId,
		UUID payerId,
		long amountNumerator,
		long amountDenominator,
		String label,
		LocalDate date,
		long observedVersion) implements Command {

	public UpdateExpenseDetailsCommand {
		Objects.requireNonNull(expenseId, "expenseId must not be null");
		Objects.requireNonNull(payerId, "payerId must not be null");
		Objects.requireNonNull(label, "label must not be null");
		Objects.requireNonNull(date, "date must not be null");
		Amount.of(Fraction.of(amountNumerator, amountDenominator));

		if (observedVersion < 1) {
			throw new IllegalArgumentException("observedVersion must be greater than or equal to 1");
		}
	}
}

package com.kartaguez.pocoma.domain.pot.event;

import java.util.Objects;

import com.kartaguez.pocoma.domain.event.EventType;
import com.kartaguez.pocoma.domain.pot.value.id.PotId;

public record PotDetailsUpdatedEvent(PotId potId, long version) implements BusinessEvent {

	public PotDetailsUpdatedEvent {
		Objects.requireNonNull(potId, "potId must not be null");

		if (version < 1) {
			throw new IllegalArgumentException("version must be greater than or equal to 1");
		}
	}

	@Override public EventType eventType() { return PocomaEventTypes.POT_DETAILS_UPDATED; }
}

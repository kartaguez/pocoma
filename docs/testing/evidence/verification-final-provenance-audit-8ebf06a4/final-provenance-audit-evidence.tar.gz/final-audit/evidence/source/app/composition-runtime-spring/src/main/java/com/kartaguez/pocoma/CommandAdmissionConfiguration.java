package com.kartaguez.pocoma;

import java.time.Clock;
import java.time.Duration;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.kartaguez.pocoma.contracts.command.CommandId;
import com.kartaguez.pocoma.engine.admit.command.port.out.RecordedCommandInsertionPort;
import com.kartaguez.pocoma.port.transaction.TransactionRunner;
import com.kartaguez.pocoma.engine.admit.command.CommandAuthenticationEvidenceFactory;
import com.kartaguez.pocoma.engine.admit.command.SubmitRecordedCommandService;
import com.kartaguez.pocoma.engine.admit.command.model.CommandAuthorizationTtl;
import com.kartaguez.pocoma.engine.admit.command.port.in.SubmitRecordedCommandUseCase;
import com.kartaguez.pocoma.engine.admit.command.port.out.CommandIdGenerator;

@ConditionalOnProperty(prefix = "pocoma.command-admission", name = "enabled", havingValue = "true")
public class CommandAdmissionConfiguration {

	@Bean
	Clock commandAdmissionClock() {
		return Clock.systemUTC();
	}

	@Bean
	CommandAuthenticationEvidenceFactory commandAuthenticationEvidenceFactory(
			@Value("${pocoma.command-admission.authorization-ttl:PT15M}") Duration ttl) {
		return new CommandAuthenticationEvidenceFactory(new CommandAuthorizationTtl(ttl));
	}

	@Bean
	CommandIdGenerator commandIdGenerator() {
		return () -> new CommandId(UUID.randomUUID());
	}

	@Bean
	SubmitRecordedCommandUseCase submitRecordedCommandUseCase(
			RecordedCommandInsertionPort commands,
			CommandIdGenerator commandIds,
			CommandAuthenticationEvidenceFactory authenticationEvidence,
			@Qualifier("commandAdmissionClock") Clock clock,
			@Qualifier("transactionRunner") TransactionRunner transactions) {
		return new SubmitRecordedCommandService(
				commands, commandIds, authenticationEvidence, clock, transactions);
	}
}

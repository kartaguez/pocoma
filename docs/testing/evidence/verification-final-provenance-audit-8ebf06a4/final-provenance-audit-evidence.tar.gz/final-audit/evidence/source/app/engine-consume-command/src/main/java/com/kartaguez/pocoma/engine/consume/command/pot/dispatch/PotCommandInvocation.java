package com.kartaguez.pocoma.engine.consume.command.pot.dispatch;

import java.util.Optional;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import com.kartaguez.pocoma.domain.event.BusinessEvent;
import com.kartaguez.pocoma.domain.pot.event.ExpenseCreatedEvent;
import com.kartaguez.pocoma.domain.pot.event.ExpenseDeletedEvent;
import com.kartaguez.pocoma.domain.pot.event.ExpenseDetailsUpdatedEvent;
import com.kartaguez.pocoma.domain.pot.event.ExpenseSharesUpdatedEvent;
import com.kartaguez.pocoma.domain.pot.event.PotCreatedEvent;
import com.kartaguez.pocoma.domain.pot.event.PotDeletedEvent;
import com.kartaguez.pocoma.domain.pot.event.PotDetailsUpdatedEvent;
import com.kartaguez.pocoma.domain.pot.event.PotShareholdersAddedEvent;
import com.kartaguez.pocoma.domain.pot.event.PotShareholdersDetailsUpdatedEvent;
import com.kartaguez.pocoma.domain.pot.event.PotShareholdersWeightsUpdatedEvent;
import com.kartaguez.pocoma.engine.consume.command.model.CommandExecutionInput;
import com.kartaguez.pocoma.engine.write.pot.context.AddPotShareholdersContext;
import com.kartaguez.pocoma.engine.write.pot.context.CreateExpenseContext;
import com.kartaguez.pocoma.engine.write.pot.context.DeleteExpenseContext;
import com.kartaguez.pocoma.engine.write.pot.context.DeletePotContext;
import com.kartaguez.pocoma.engine.write.pot.context.UpdateExpenseDetailsContext;
import com.kartaguez.pocoma.engine.write.pot.context.UpdateExpenseSharesContext;
import com.kartaguez.pocoma.engine.write.pot.context.UpdatePotDetailsContext;
import com.kartaguez.pocoma.engine.write.pot.context.UpdatePotShareholdersDetailsContext;
import com.kartaguez.pocoma.engine.write.pot.context.UpdatePotShareholdersWeightsContext;
import com.kartaguez.pocoma.domain.pot.version.PotGlobalVersion;
import com.kartaguez.pocoma.engine.write.pot.port.event.EventPublisherPort;
import com.kartaguez.pocoma.engine.write.pot.port.persistence.ExpenseContextPort;
import com.kartaguez.pocoma.engine.write.pot.port.persistence.PotContextPort;

/** Invocation-local capture of typed Events and business versions produced by Pot WRITE. */
final class PotCommandInvocation implements EventPublisherPort {

	private final Set<CommandExecutionInput> inputs = new LinkedHashSet<>();
	private final List<BusinessEvent> events = new ArrayList<>();

	List<CommandExecutionInput> inputs() {
		return List.copyOf(inputs);
	}

	List<BusinessEvent> events() {
		return List.copyOf(events);
	}

	PotContextPort recording(PotContextPort delegate) {
		return new PotContextPort() {
			@Override
			public Optional<AddPotShareholdersContext> loadAddPotShareholdersContext(
					com.kartaguez.pocoma.domain.pot.value.id.PotId potId) {
				return delegate.loadAddPotShareholdersContext(potId).map(PotCommandInvocation.this::capture);
			}

			@Override
			public Optional<CreateExpenseContext> loadCreateExpenseContext(
					com.kartaguez.pocoma.domain.pot.value.id.PotId potId) {
				return delegate.loadCreateExpenseContext(potId).map(PotCommandInvocation.this::capture);
			}

			@Override
			public Optional<DeletePotContext> loadDeletePotContext(
					com.kartaguez.pocoma.domain.pot.value.id.PotId potId) {
				return delegate.loadDeletePotContext(potId).map(PotCommandInvocation.this::capture);
			}

			@Override
			public Optional<UpdatePotDetailsContext> loadUpdatePotDetailsContext(
					com.kartaguez.pocoma.domain.pot.value.id.PotId potId) {
				return delegate.loadUpdatePotDetailsContext(potId).map(PotCommandInvocation.this::capture);
			}

			@Override
			public Optional<UpdatePotShareholdersDetailsContext> loadUpdatePotShareholdersDetailsContext(
					com.kartaguez.pocoma.domain.pot.value.id.PotId potId) {
				return delegate.loadUpdatePotShareholdersDetailsContext(potId).map(PotCommandInvocation.this::capture);
			}

			@Override
			public Optional<UpdatePotShareholdersWeightsContext> loadUpdatePotShareholdersWeightsContext(
					com.kartaguez.pocoma.domain.pot.value.id.PotId potId) {
				return delegate.loadUpdatePotShareholdersWeightsContext(potId).map(PotCommandInvocation.this::capture);
			}
		};
	}

	ExpenseContextPort recording(ExpenseContextPort delegate) {
		return new ExpenseContextPort() {
			@Override
			public Optional<DeleteExpenseContext> loadDeleteExpenseContext(
					com.kartaguez.pocoma.domain.pot.value.id.ExpenseId expenseId) {
				return delegate.loadDeleteExpenseContext(expenseId).map(PotCommandInvocation.this::capture);
			}

			@Override
			public Optional<UpdateExpenseDetailsContext> loadUpdateExpenseDetailsContext(
					com.kartaguez.pocoma.domain.pot.value.id.ExpenseId expenseId) {
				return delegate.loadUpdateExpenseDetailsContext(expenseId).map(PotCommandInvocation.this::capture);
			}

			@Override
			public Optional<UpdateExpenseSharesContext> loadUpdateExpenseSharesContext(
					com.kartaguez.pocoma.domain.pot.value.id.ExpenseId expenseId) {
				return delegate.loadUpdateExpenseSharesContext(expenseId).map(PotCommandInvocation.this::capture);
			}
		};
	}

	@Override public void publish(ExpenseCreatedEvent event) { events.add(event); }
	@Override public void publish(ExpenseDeletedEvent event) { events.add(event); }
	@Override public void publish(ExpenseDetailsUpdatedEvent event) { events.add(event); }
	@Override public void publish(ExpenseSharesUpdatedEvent event) { events.add(event); }
	@Override public void publish(PotCreatedEvent event) { events.add(event); }
	@Override public void publish(PotDeletedEvent event) { events.add(event); }
	@Override public void publish(PotDetailsUpdatedEvent event) { events.add(event); }
	@Override public void publish(PotShareholdersAddedEvent event) { events.add(event); }
	@Override public void publish(PotShareholdersDetailsUpdatedEvent event) { events.add(event); }
	@Override public void publish(PotShareholdersWeightsUpdatedEvent event) { events.add(event); }

	private <T> T capture(T context) {
		if (context instanceof AddPotShareholdersContext value) record(value.potGlobalVersion());
		else if (context instanceof CreateExpenseContext value) record(value.potGlobalVersion());
		else if (context instanceof DeletePotContext value) record(value.potGlobalVersion());
		else if (context instanceof UpdatePotDetailsContext value) record(value.potGlobalVersion());
		else if (context instanceof UpdatePotShareholdersDetailsContext value) record(value.potGlobalVersion());
		else if (context instanceof UpdatePotShareholdersWeightsContext value) record(value.potGlobalVersion());
		else if (context instanceof DeleteExpenseContext value) record(value.potGlobalVersion());
		else if (context instanceof UpdateExpenseDetailsContext value) record(value.potGlobalVersion());
		else if (context instanceof UpdateExpenseSharesContext value) record(value.potGlobalVersion());
		return context;
	}

	private void record(PotGlobalVersion version) {
		inputs.add(new CommandExecutionInput("POT", version.potId().value().toString(), version.version()));
	}
}

package com.kartaguez.pocoma.domain.pot.aggregate;

import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.kartaguez.pocoma.domain.pot.entity.Shareholder;
import com.kartaguez.pocoma.domain.pot.exception.BusinessRuleViolationException;
import com.kartaguez.pocoma.domain.pot.value.Name;
import com.kartaguez.pocoma.domain.pot.value.UserId;
import com.kartaguez.pocoma.domain.pot.value.Weight;
import com.kartaguez.pocoma.domain.pot.value.id.PotId;
import com.kartaguez.pocoma.domain.pot.value.id.ShareholderId;

public final class PotShareholders {

	private final PotId potId;
	private final Map<ShareholderId, Shareholder> shareholders;
	private final Set<ShareholderId> addedShareholderIds;
	private final Set<ShareholderId> updatedShareholderIds;

	public PotShareholders(PotId potId, Set<Shareholder> shareholders) {
		this.potId = Objects.requireNonNull(potId, "potId must not be null");
		this.shareholders = Set.copyOf(Objects.requireNonNull(shareholders, "shareholders must not be null")).stream()
				.collect(Collectors.toMap(Shareholder::id, Function.identity()));
		this.addedShareholderIds = new HashSet<>();
		this.updatedShareholderIds = new HashSet<>();
	}

	public static PotShareholders reconstitute(PotId potId, Set<Shareholder> shareholders) {
		return new PotShareholders(potId, shareholders);
	}

	public Shareholder addShareholder(Name name, Weight weight, UserId userId) {
		return addShareholder(name, weight, userId, () -> ShareholderId.of(UUID.randomUUID()));
	}

	Shareholder addShareholder(Name name, Weight weight, UserId userId,
			java.util.function.Supplier<ShareholderId> identities) {
		Shareholder shareholder = new Shareholder(
				Objects.requireNonNull(identities.get(), "shareholder id must not be null"),
				potId,
				Objects.requireNonNull(name, "name must not be null"),
				Objects.requireNonNull(weight, "weight must not be null"),
				userId,
				false);

		if (shareholders.putIfAbsent(shareholder.id(), shareholder) != null) {
			throw new IllegalStateException("Generated shareholder identity already exists");
		}
		addedShareholderIds.add(shareholder.id());
		return shareholder;
	}

	public void updateShareholderDetails(ShareholderId shareholderId, Name name, UserId userId) {
		Objects.requireNonNull(shareholderId, "shareholderId must not be null");
		Objects.requireNonNull(name, "name must not be null");

		Shareholder shareholder = requireShareholder(shareholderId);
		shareholders.put(
				shareholderId,
				new Shareholder(
						shareholder.id(),
						shareholder.potId(),
						name,
						shareholder.weight(),
						userId,
						shareholder.deleted()));
		markAsUpdated(shareholderId);
	}

	public void updateShareholderWeight(ShareholderId shareholderId, Weight weight) {
		Objects.requireNonNull(shareholderId, "shareholderId must not be null");
		Objects.requireNonNull(weight, "weight must not be null");

		Shareholder shareholder = requireShareholder(shareholderId);
		shareholders.put(
				shareholderId,
				new Shareholder(
						shareholder.id(),
						shareholder.potId(),
						shareholder.name(),
						weight,
						shareholder.userId(),
						shareholder.deleted()));
		markAsUpdated(shareholderId);
	}

	public PotId potId() {
		return potId;
	}

	public Map<ShareholderId, Shareholder> shareholders() {
		return Map.copyOf(shareholders);
	}

	public Set<ShareholderId> addedShareholderIds() {
		return Set.copyOf(addedShareholderIds);
	}

	public Set<ShareholderId> updatedShareholderIds() {
		return Set.copyOf(updatedShareholderIds);
	}

	private Shareholder requireShareholder(ShareholderId shareholderId) {
		Shareholder shareholder = shareholders.get(shareholderId);
		if (shareholder == null) {
			throw new BusinessRuleViolationException(
					"SHAREHOLDER_NOT_PRESENT",
					"Shareholder does not belong to this pot");
		}
		if (shareholder.deleted()) {
			throw new BusinessRuleViolationException(
					"SHAREHOLDER_DELETED",
					"Shareholder cannot be modified because it is deleted");
		}
		return shareholder;
	}

	private void markAsUpdated(ShareholderId shareholderId) {
		if (!addedShareholderIds.contains(shareholderId)) {
			updatedShareholderIds.add(shareholderId);
		}
	}
}

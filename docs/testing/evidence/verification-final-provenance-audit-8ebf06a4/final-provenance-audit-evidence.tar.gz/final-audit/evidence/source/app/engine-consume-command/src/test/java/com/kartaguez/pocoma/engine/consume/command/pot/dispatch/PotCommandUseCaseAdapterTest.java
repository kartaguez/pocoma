package com.kartaguez.pocoma.engine.consume.command.pot.dispatch;

import java.util.Optional;
import com.kartaguez.pocoma.engine.write.pot.service.PotAuthorizationGuard;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Instant;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

import org.junit.jupiter.api.Test;

import com.kartaguez.pocoma.domain.authorization.Permission;
import com.kartaguez.pocoma.domain.pot.aggregate.PotShareholders;
import com.kartaguez.pocoma.domain.pot.entity.Shareholder;
import com.kartaguez.pocoma.domain.pot.event.PotDetailsUpdatedEvent;
import com.kartaguez.pocoma.domain.pot.event.PotShareholdersAddedEvent;
import com.kartaguez.pocoma.domain.pot.exception.BusinessRuleViolationException;
import com.kartaguez.pocoma.domain.pot.policy.CreatePotAuthorizationPolicy;
import com.kartaguez.pocoma.domain.pot.value.Fraction;
import com.kartaguez.pocoma.domain.pot.value.Label;
import com.kartaguez.pocoma.domain.pot.value.Name;
import com.kartaguez.pocoma.domain.pot.value.UserId;
import com.kartaguez.pocoma.domain.pot.value.Weight;
import com.kartaguez.pocoma.domain.pot.value.id.PotId;
import com.kartaguez.pocoma.domain.pot.value.id.ShareholderId;
import com.kartaguez.pocoma.engine.consume.command.dispatch.CommandDispatcher;
import com.kartaguez.pocoma.engine.consume.command.dispatch.CommandUseCase;
import com.kartaguez.pocoma.engine.consume.command.dispatch.CommandUseCaseResult;
import com.kartaguez.pocoma.engine.consume.command.execution.CommandExecutionInvariantViolationException;
import com.kartaguez.pocoma.engine.consume.command.model.ResolvedCommandAuthorization;
import com.kartaguez.pocoma.engine.consume.command.model.CommandExecutionAuthorization;
import com.kartaguez.pocoma.engine.consume.command.model.ResolvedCommandAuthorization;
import com.kartaguez.pocoma.domain.useridentity.PocomaUserId;
import com.kartaguez.pocoma.engine.write.pot.context.AddPotShareholdersContext;
import com.kartaguez.pocoma.engine.write.pot.context.UpdatePotDetailsContext;
import com.kartaguez.pocoma.engine.write.pot.exception.BusinessEntityNotFoundException;
import com.kartaguez.pocoma.engine.write.pot.exception.PotVersionCasConflictException;
import com.kartaguez.pocoma.domain.pot.version.PotGlobalVersion;
import com.kartaguez.pocoma.engine.consume.command.pot.intent.AddPotShareholdersCommand;
import com.kartaguez.pocoma.engine.consume.command.pot.intent.CreatePotCommand;
import com.kartaguez.pocoma.engine.write.pot.port.persistence.ExpenseContextPort;
import com.kartaguez.pocoma.engine.write.pot.port.persistence.ExpenseHeaderPort;
import com.kartaguez.pocoma.engine.write.pot.port.persistence.ExpenseSharesPort;
import com.kartaguez.pocoma.engine.write.pot.port.persistence.PotContextPort;
import com.kartaguez.pocoma.engine.write.pot.port.persistence.PotGlobalVersionPort;
import com.kartaguez.pocoma.engine.write.pot.port.persistence.PotHeaderPort;
import com.kartaguez.pocoma.engine.write.pot.port.persistence.PotShareholdersPort;
import com.kartaguez.pocoma.engine.write.pot.security.UserContext;
import com.kartaguez.pocoma.engine.write.pot.snapshot.PotHeaderSnapshot;

class PotCommandUseCaseAdapterTest {

	private static final UUID USER_ID = UUID.fromString("10000000-0000-0000-0000-000000000001");
	private static final PotId POT_ID = PotId.of(UUID.fromString("20000000-0000-0000-0000-000000000001"));

	@Test
	void passesPermissionsWithoutMappingAndPreservesTheUserIdentity() {
		AtomicReference<UserContext> received = new AtomicReference<>();
		TestAdapter adapter = new TestAdapter((invocation, userContext) -> {
			received.set(userContext);
			return snapshot(POT_ID, 1);
		});
		Set<Permission> permissions = Set.of(
				new Permission("POT", "CREATE"),
				new Permission("POT", "UPDATE"),
				new Permission("FUTURE_FEATURE", "VIEW"));

		adapter.execute(authorization(permissions), command());

		assertEquals(UserId.of(USER_ID), received.get().userId());
		assertEquals(permissions, received.get().permissions());
		assertThrows(UnsupportedOperationException.class, () -> received.get().permissions().clear());
	}

	@Test
	void targetResolvedAuthorizationSuppliesTheCurrentUserToTheBusinessPolicyContext() {
		AtomicReference<UserContext> received = new AtomicReference<>();
		TestAdapter adapter = new TestAdapter((invocation, userContext) -> {
			received.set(userContext);
			return snapshot(POT_ID, 1);
		});
		Set<Permission> permissions = Set.of(new Permission("POT", "CREATE"));

		adapter.execute(new ResolvedCommandAuthorization(new PocomaUserId(USER_ID), permissions), command());

		assertEquals(UserId.of(USER_ID), received.get().userId());
		assertEquals(permissions, received.get().permissions());
	}

	@Test
	void unknownPermissionsDoNotPreventExecution() {
		AtomicBoolean invoked = new AtomicBoolean();
		TestAdapter adapter = new TestAdapter((invocation, ignored) -> {
			invoked.set(true);
			return snapshot(POT_ID, 1);
		});

		assertInstanceOf(CommandUseCaseResult.Succeeded.class,
				adapter.execute(authorization(Set.of(new Permission("FUTURE_FEATURE", "VIEW"))), command()));

		assertTrue(invoked.get());
	}

	@Test
	void returnsTypedEventsAndThePotVersionActuallyRead() {
		PotDetailsUpdatedEvent event = new PotDetailsUpdatedEvent(POT_ID, 8);
		TestAdapter adapter = new TestAdapter((invocation, ignored) -> {
			PotContextPort contextPort = invocation.recording(new PotContextPort() {
				@Override public Optional<UpdatePotDetailsContext> loadUpdatePotDetailsContext(PotId potId) {
					return Optional.of(new UpdatePotDetailsContext(new PotGlobalVersion(potId, 7), false, UserId.of(USER_ID), 7L));
				}
			});
			contextPort.loadUpdatePotDetailsContext(POT_ID);
			invocation.publish(event);
			return snapshot(POT_ID, 8);
		});

		CommandUseCaseResult.Succeeded result = assertInstanceOf(CommandUseCaseResult.Succeeded.class,
				adapter.execute(authorization(Set.of()), command()));

		assertEquals(List.of(new com.kartaguez.pocoma.engine.consume.command.model.CommandExecutionInput(
				"POT", POT_ID.value().toString(), 7)), result.inputs());
		assertEquals(1, result.events().size());
		assertSame(event, result.events().getFirst());
	}

	@Test
	void convertsOnlyExpectedBusinessExceptionsToRejections() {
		assertRejected("RULE", new BusinessRuleViolationException("RULE", "rejected"));
		assertRejected("OBSOLETE_COMMAND", new BusinessRuleViolationException("OBSOLETE_COMMAND", "obsolete"));
		assertRejected("INVALID_OBSERVED_VERSION", new BusinessRuleViolationException("INVALID_OBSERVED_VERSION", "invalid"));

		for (RuntimeException failure : List.of(new PotVersionCasConflictException("conflict"),
                new BusinessEntityNotFoundException("POT_HEADER", "missing"),
                new com.kartaguez.pocoma.engine.write.pot.exception.AggregateTransitionConsistencyException("cardinality"))) {
            TestAdapter failing = new TestAdapter((invocation, ignored) -> { throw failure; });
            assertSame(failure, assertThrows(failure.getClass(), () -> failing.execute(authorization(Set.of()), command())));
        }

		TechnicalException technical = new TechnicalException();
		TestAdapter adapter = new TestAdapter((invocation, ignored) -> { throw technical; });
		assertSame(technical, assertThrows(TechnicalException.class,
				() -> adapter.execute(authorization(Set.of()), command())));
	}


	@Test
	void refusesToTurnAnExceptionAfterEventProductionIntoARejection() {
		TestAdapter adapter = new TestAdapter((invocation, ignored) -> {
			invocation.publish(new PotDetailsUpdatedEvent(POT_ID, 2));
			throw new BusinessRuleViolationException("TOO_LATE", "too late");
		});

		CommandExecutionInvariantViolationException exception = assertThrows(
				CommandExecutionInvariantViolationException.class,
				() -> adapter.execute(authorization(Set.of()), command()));
		assertInstanceOf(BusinessRuleViolationException.class, exception.getCause());
	}

	@Test
	void acceptsAValidSuccessWithoutEvents() {
		CommandUseCaseResult.Succeeded result = assertInstanceOf(CommandUseCaseResult.Succeeded.class,
				new TestAdapter((invocation, ignored) -> snapshot(POT_ID, 1))
						.execute(authorization(Set.of()), command()));
		assertEquals(List.of(), result.inputs());
		assertEquals(List.of(), result.events());
	}

	@Test
	void createPotRejectsAConflictingCreatorBeforeCallingAnyPort() {
		AtomicBoolean called = new AtomicBoolean();
		PotGlobalVersionPort versions = new PotGlobalVersionPort() {
			@Override public void save(PotGlobalVersion version) { called.set(true); }
		};
		CreatePotCommandUseCaseAdapter adapter = new CreatePotCommandUseCaseAdapter(
				versions, new PotHeaderPort() { }, new CreatePotAuthorizationPolicy());

		CommandUseCaseResult.Rejected result = assertInstanceOf(CommandUseCaseResult.Rejected.class,
				adapter.execute(authorization(Set.of(new Permission("POT", "CREATE"))),
						new CreatePotCommand("Trip", UUID.randomUUID())));

		assertEquals("NOT_AUTHORIZED_ON_RESOURCE", result.reason().code());
		assertEquals(List.of(), result.inputs());
		assertFalse(called.get());
	}

	@Test
	void createPotUsesTheExistingServiceAndReturnsItsTypedEvent() {
		AtomicReference<PotGlobalVersion> savedVersion = new AtomicReference<>();
		AtomicReference<com.kartaguez.pocoma.domain.pot.aggregate.PotHeader> savedHeader = new AtomicReference<>();
		CreatePotCommandUseCaseAdapter adapter = new CreatePotCommandUseCaseAdapter(
				new PotGlobalVersionPort() {
					@Override public void save(PotGlobalVersion version) { savedVersion.set(version); }
				},
				new PotHeaderPort() {
					@Override public void saveNew(com.kartaguez.pocoma.domain.pot.aggregate.PotHeader header,
							long version) { savedHeader.set(header); }
				},
				new CreatePotAuthorizationPolicy());

		CommandUseCaseResult.Succeeded result = assertInstanceOf(CommandUseCaseResult.Succeeded.class,
				adapter.execute(authorization(Set.of(new Permission("POT", "CREATE"))), command()));

		assertEquals(1, savedVersion.get().version());
		assertEquals("Trip", savedHeader.get().label().value());
		assertInstanceOf(com.kartaguez.pocoma.domain.pot.event.PotCreatedEvent.class, result.events().getFirst());
		assertEquals(List.of(), result.inputs());
	}

	@Test
	void addShareholdersCapturesGeneratedIdsAndObservedPotVersion() {
		UserId creator = UserId.of(USER_ID);
		Shareholder existing = Shareholder.reconstitute(ShareholderId.of(UUID.randomUUID()), POT_ID,
				Name.of("Existing"), Weight.of(Fraction.ONE), null, false);
		PotShareholders aggregate = PotShareholders.reconstitute(POT_ID, Set.of(existing));
		PotShareholdersPort shareholders = new PotShareholdersPort() {
			@Override public PotShareholders loadActiveAtVersion(PotId potId, long version) { return aggregate; }
			@Override public void save(PotShareholders value, PotGlobalVersion current, PotGlobalVersion next) { }
		};
		AddPotShareholdersCommandUseCaseAdapter adapter = new AddPotShareholdersCommandUseCaseAdapter(
				new PotContextPort() {
					@Override public Optional<AddPotShareholdersContext> loadAddPotShareholdersContext(PotId potId) {
						return Optional.of(new AddPotShareholdersContext(new PotGlobalVersion(potId, 3), false, creator));
					}
				}, shareholders, new PotGlobalVersionPort() {
					@Override public void updateIfActive(PotGlobalVersion current, PotGlobalVersion next) { }
				}, new PotAuthorizationGuard());

		CommandUseCaseResult.Succeeded result = assertInstanceOf(CommandUseCaseResult.Succeeded.class,
				adapter.execute(authorization(Set.of(new Permission("SHAREHOLDER", "CREATE"))),
						new AddPotShareholdersCommand(POT_ID.value(),
								Set.of(new AddPotShareholdersCommand.ShareholderInput("Alice", 1, 2)), 3)));

		PotShareholdersAddedEvent event = assertInstanceOf(PotShareholdersAddedEvent.class, result.events().getFirst());
		assertEquals(aggregate.addedShareholderIds(), event.shareholderIds());
		assertEquals(3, result.inputs().getFirst().version());
	}

	@Test
	void allTenSpecializedAdaptersCanPopulateTheGenericDispatcher() {
		PotContextPort potContexts = new PotContextPort() { };
		ExpenseContextPort expenseContexts = new ExpenseContextPort() { };
		PotGlobalVersionPort versions = new PotGlobalVersionPort() { };
		PotHeaderPort potHeaders = new PotHeaderPort() { };
		ExpenseHeaderPort expenseHeaders = new ExpenseHeaderPort() { };
		ExpenseSharesPort expenseShares = new ExpenseSharesPort() { };
		PotShareholdersPort shareholders = new PotShareholdersPort() {
			@Override public PotShareholders loadActiveAtVersion(PotId potId, long version) { throw new AssertionError(); }
			@Override public void save(PotShareholders value, PotGlobalVersion current, PotGlobalVersion next) {
				throw new AssertionError();
			}
		};
		List<CommandUseCase<?>> adapters = List.of(
				new CreatePotCommandUseCaseAdapter(versions, potHeaders, new CreatePotAuthorizationPolicy()),
				new CreateExpenseCommandUseCaseAdapter(potContexts, versions, expenseHeaders, expenseShares,
						new PotAuthorizationGuard()),
				new AddPotShareholdersCommandUseCaseAdapter(potContexts, shareholders, versions,
						new PotAuthorizationGuard()),
				new DeletePotCommandUseCaseAdapter(potContexts, potHeaders, versions, new PotAuthorizationGuard()),
				new DeleteExpenseCommandUseCaseAdapter(expenseContexts, expenseHeaders, versions,
						new PotAuthorizationGuard()),
				new UpdatePotDetailsCommandUseCaseAdapter(potContexts, potHeaders, versions,
						new PotAuthorizationGuard()),
				new UpdateExpenseDetailsCommandUseCaseAdapter(expenseContexts, expenseHeaders, versions,
						new PotAuthorizationGuard()),
				new UpdateExpenseSharesCommandUseCaseAdapter(expenseContexts, expenseShares, versions,
						new PotAuthorizationGuard()),
				new UpdatePotShareholdersDetailsCommandUseCaseAdapter(potContexts, shareholders, versions,
						new PotAuthorizationGuard()),
				new UpdatePotShareholdersWeightsCommandUseCaseAdapter(potContexts, shareholders, versions,
						new PotAuthorizationGuard()));

		new CommandDispatcher(adapters);
		assertEquals(10, adapters.stream().map(CommandUseCase::commandClass).distinct().count());
	}

	@Test
	void keepsEventsAndProvenanceIsolatedBetweenConcurrentInvocations()
			throws ExecutionException, InterruptedException {
		UUID firstUser = UUID.randomUUID();
		UUID secondUser = UUID.randomUUID();
		CountDownLatch entered = new CountDownLatch(2);
		TestAdapter adapter = new TestAdapter((invocation, userContext) -> {
			entered.countDown();
			try {
				entered.await();
			}
			catch (InterruptedException exception) {
				Thread.currentThread().interrupt();
				throw new IllegalStateException(exception);
			}
			PotId invocationPotId = PotId.of(userContext.userId().value());
			PotContextPort contextPort = invocation.recording(new PotContextPort() {
				@Override public Optional<UpdatePotDetailsContext> loadUpdatePotDetailsContext(PotId potId) {
					return Optional.of(new UpdatePotDetailsContext(new PotGlobalVersion(potId, 4), false, userContext.userId(), 4L));
				}
			});
			contextPort.loadUpdatePotDetailsContext(invocationPotId);
			invocation.publish(new PotDetailsUpdatedEvent(invocationPotId, 5));
			return snapshot(invocationPotId, 5);
		});

		try (ExecutorService executor = Executors.newFixedThreadPool(2)) {
			Future<CommandUseCaseResult> first = executor.submit(
					() -> adapter.execute(authorization(firstUser, Set.of()), command()));
			Future<CommandUseCaseResult> second = executor.submit(
					() -> adapter.execute(authorization(secondUser, Set.of()), command()));

			assertInvocationBelongsTo(first.get(), firstUser);
			assertInvocationBelongsTo(second.get(), secondUser);
		}
	}

	private static void assertRejected(String expectedCode, RuntimeException failure) {
		TestAdapter adapter = new TestAdapter((invocation, ignored) -> { throw failure; });
		CommandUseCaseResult.Rejected result = assertInstanceOf(CommandUseCaseResult.Rejected.class,
				adapter.execute(authorization(Set.of()), command()));
		assertEquals(expectedCode, result.reason().code());
		assertEquals(List.of(), result.inputs());
	}

	private static ResolvedCommandAuthorization authorization(Set<Permission> permissions) {
		return authorization(USER_ID, permissions);
	}

	private static ResolvedCommandAuthorization authorization(UUID userId, Set<Permission> permissions) {
		return new ResolvedCommandAuthorization(new PocomaUserId(userId), permissions);
	}

	private static void assertInvocationBelongsTo(CommandUseCaseResult executionResult, UUID expectedId) {
		CommandUseCaseResult.Succeeded result = assertInstanceOf(CommandUseCaseResult.Succeeded.class, executionResult);
		assertEquals(expectedId.toString(), result.inputs().getFirst().id());
		PotDetailsUpdatedEvent event = assertInstanceOf(PotDetailsUpdatedEvent.class, result.events().getFirst());
		assertEquals(PotId.of(expectedId), event.potId());
	}

	private static CreatePotCommand command() {
		return new CreatePotCommand("Trip", USER_ID);
	}

	private static PotHeaderSnapshot snapshot(PotId potId, long version) {
		return new PotHeaderSnapshot(potId, Label.of("Trip"), UserId.of(USER_ID), false, version);
	}

	private static final class TestAdapter extends AbstractPotCommandUseCaseAdapter<CreatePotCommand> {
		private final AdaptedExecution execution;
		private TestAdapter(AdaptedExecution execution) { this.execution = execution; }
		@Override public Class<CreatePotCommand> commandClass() { return CreatePotCommand.class; }
		@Override public CommandUseCaseResult execute(
				CommandExecutionAuthorization authorization, CreatePotCommand command) {
			return executeAdapted(authorization, command, execution);
		}
	}

	private static final class TechnicalException extends RuntimeException {
	}

}

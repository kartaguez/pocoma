from pathlib import Path
import csv, json, shutil, subprocess, sys, time, xml.etree.ElementTree as ET
ROOT = Path('/tmp/pocoma-takeover-validation-20261015')
SUITE = 'com.kartaguez.pocoma.architecture.ccr.CommandResultConsumptionChainPostgresTest'
phase, app, first, last, selection, expected = sys.argv[1:]
app = Path(app)
expected = int(expected)
folder = ROOT / (phase + '-runs')
folder.mkdir(exist_ok=True)
fields = ['run','exit_code','tests','failures','errors','skipped','seconds','compilations','status']

def preserve(number, log, code, seconds):
    dest = folder / f'{number:03d}'
    dest.mkdir(exist_ok=True)
    shutil.copy2(log, dest / 'maven.log')
    data = dict(run=number, exit_code=code, tests=0, failures=0, errors=0, skipped=0, seconds=round(seconds,3), compilations=log.read_text().count('Compiling '), status='NO_REPORT')
    for p in (app / 'architecture-tests/target/surefire-reports').glob('*' + SUITE + '*'):
        if p.is_file(): shutil.copy2(p, dest / p.name)
    xml = dest / ('TEST-' + SUITE + '.xml')
    if xml.exists():
        suite = ET.parse(xml).getroot()
        for key in ['tests','failures','errors','skipped']: data[key] = int(suite.get(key,0))
        data['status'] = 'PASS' if code == 0 and data['tests'] == expected and not any(data[k] for k in ['failures','errors','skipped']) else 'FAIL'
    summary = folder / 'results.csv'
    exists = summary.exists()
    with summary.open('a', newline='') as f:
        writer=csv.DictWriter(f, fieldnames=fields)
        if not exists: writer.writeheader()
        writer.writerow(data)
    print(phase, json.dumps(data), flush=True)
    return data['status'] == 'PASS'

if phase == 'baseline' and int(first) == 2 and not (folder / 'results.csv').exists():
    preserve(1, ROOT / 'baseline-lifecycle-preflight.log', 0, 12.744)

success=True
for n in range(int(first), int(last)+1):
    report_dir = app / 'architecture-tests/target/surefire-reports'
    for p in report_dir.glob('*' + SUITE + '*'):
        if p.is_file(): p.unlink()
    command=['./mvnw','-o','-pl','architecture-tests','-am','-Dtest='+selection,'-Dsurefire.failIfNoSpecifiedTests=false','-Dsurefire.rerunFailingTestsCount=0','-Dmaven.main.skip=true','-Dmaven.compiler.useIncrementalCompilation=false','test']
    log=ROOT / (phase + '-current.log')
    start=time.monotonic()
    with log.open('w') as f: result=subprocess.run(command, cwd=app, stdout=f, stderr=subprocess.STDOUT)
    success = preserve(n,log,result.returncode,time.monotonic()-start) and success
sys.exit(0 if success else 1)

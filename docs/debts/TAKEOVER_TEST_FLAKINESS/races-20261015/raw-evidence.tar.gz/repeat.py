from pathlib import Path
import csv,json,shutil,subprocess,sys,time,xml.etree.ElementTree as E
root=Path('/tmp/pocoma-takeover-races-20261015')
app=Path('/Users/julien.guezennec/Dev/projects/pocoma/app')
suite='com.kartaguez.pocoma.architecture.ccr.CommandResultTakeoverRacePostgresTest'
expected={'inFlightPublicationLosesFenceAndUnblocksWinnerPublication','committedFinalCasMakesWaitingTakeoverObserveDone','rolledBackFinalCasReleasesSlotAndAllowsTakeover','twoConcurrentTakeoversInstallOnlyOneCurrentClaim','rolledBackTakeoverLetsWaitingContenderReuseAttemptTwo'}
folder=root/'runs';folder.mkdir(exist_ok=True)
fields=['run','exit_code','tests','failures','errors','skipped','block_witnesses','compilations','seconds','status']
for n in range(int(sys.argv[1]),int(sys.argv[2])+1):
 report=app/'architecture-tests/target/surefire-reports'
 for f in report.glob('*'+suite+'*'):
  if f.is_file():f.unlink()
 dest=folder/f'{n:03d}';dest.mkdir(exist_ok=False)
 command=['./mvnw','-o','-pl','architecture-tests','-am','-Dtest=CommandResultTakeoverRacePostgresTest','-Dsurefire.failIfNoSpecifiedTests=false','-Dsurefire.rerunFailingTestsCount=0','-Dmaven.main.skip=true','-Dmaven.compiler.useIncrementalCompilation=false','test']
 start=time.monotonic()
 with (dest/'maven.log').open('w') as log: result=subprocess.run(command,cwd=app,stdout=log,stderr=subprocess.STDOUT)
 for f in report.glob('*'+suite+'*'):
  if f.is_file():shutil.copy2(f,dest/f.name)
 row=dict(run=n,exit_code=result.returncode,tests=0,failures=0,errors=0,skipped=0,block_witnesses=0,compilations=(dest/'maven.log').read_text().count('Compiling '),seconds=round(time.monotonic()-start,3),status='NO_REPORT')
 xml=dest/('TEST-'+suite+'.xml')
 if xml.exists():
  s=E.parse(xml).getroot();cases=s.findall('testcase')
  for k in ['tests','failures','errors','skipped']:row[k]=int(s.get(k,0))
  outputs=[c.findtext('system-out','') for c in cases]
  row['block_witnesses']=sum(t.count('BLOCK kind=') for t in outputs)
  names={c.get('name') for c in cases}
  good=names==expected and all(t.count('BLOCK kind=')==1 and t.count('BARRIER reached=')==1 for t in outputs)
  row['status']='PASS' if result.returncode==0 and row['tests']==5 and not any(row[k] for k in ['failures','errors','skipped']) and good else 'FAIL'
 summary=folder/'results.csv';exists=summary.exists()
 with summary.open('a',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=fields,lineterminator='\n')
  if not exists:writer.writeheader()
  writer.writerow(row)
 print(json.dumps(row),flush=True)
 if row['status']!='PASS':sys.exit(1)
